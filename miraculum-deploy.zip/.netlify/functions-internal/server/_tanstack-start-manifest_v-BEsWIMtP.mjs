//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BEsWIMtP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/miraculum-site/src/routes/__root.tsx",
		children: [
			"/",
			"/crm-ukazka",
			"/logo-greenscreen",
			"/privacy-policy",
			"/terms-of-service"
		],
		preloads: ["/assets/index-P9FzIesV.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-P9FzIesV.js"
		} }]
	},
	"/": {
		filePath: "/home/claude/miraculum-site/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CVYCU20b.js", "/assets/Logo-avlr0TCz.js"]
	},
	"/crm-ukazka": {
		filePath: "/home/claude/miraculum-site/src/routes/crm-ukazka.tsx",
		children: void 0,
		preloads: ["/assets/crm-ukazka-BTA4G7ps.js"]
	},
	"/logo-greenscreen": {
		filePath: "/home/claude/miraculum-site/src/routes/logo-greenscreen.tsx",
		children: void 0,
		preloads: ["/assets/logo-greenscreen-DHgIs98X.js", "/assets/Logo-avlr0TCz.js"]
	},
	"/privacy-policy": {
		filePath: "/home/claude/miraculum-site/src/routes/privacy-policy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-policy-BkiyM0Yk.js", "/assets/Logo-avlr0TCz.js"]
	},
	"/terms-of-service": {
		filePath: "/home/claude/miraculum-site/src/routes/terms-of-service.tsx",
		children: void 0,
		preloads: ["/assets/terms-of-service-C-WINH15.js", "/assets/Logo-avlr0TCz.js"]
	}
} });
//#endregion
export { tsrStartManifest };
