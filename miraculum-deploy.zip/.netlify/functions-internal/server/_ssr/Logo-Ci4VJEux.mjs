import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Logo-Ci4VJEux.js
var import_jsx_runtime = require_jsx_runtime();
var logo_transparent_png_asset_default = {
	version: 1,
	asset_id: "25ec2651-969b-4431-a540-4945434111ba",
	project_id: "87e660ba-70d7-49a3-a089-373cb69d7c87",
	url: "/__l5e/assets-v1/25ec2651-969b-4431-a540-4945434111ba/logo-transparent.png",
	r2_key: "a/v1/87e660ba-70d7-49a3-a089-373cb69d7c87/25ec2651-969b-4431-a540-4945434111ba/logo-transparent.png",
	original_filename: "logo-transparent.png",
	size: 729399,
	content_type: "image/png",
	created_at: "2026-07-21T11:06:18Z"
};
function Logo({ size = 32, className, title = "Logo" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: logo_transparent_png_asset_default.url,
		width: size,
		height: size,
		alt: title,
		className,
		style: { objectFit: "contain" }
	});
}
//#endregion
export { Logo as t };
