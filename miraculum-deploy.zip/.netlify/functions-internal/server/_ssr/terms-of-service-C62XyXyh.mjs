import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Logo } from "./Logo-Ci4VJEux.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-of-service-C62XyXyh.js
var import_jsx_runtime = require_jsx_runtime();
function TermsOfService() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-brand-navy text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b",
			style: { borderColor: "var(--color-brand-border-dark)" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-6xl mx-auto px-6 h-16 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
						size: 36,
						className: "text-white"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-brand-green hover:bg-brand-green-dark transition-colors shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						width: "16",
						height: "16",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19 12H5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 19l-7-7 7-7" })]
					}), "Späť na úvod"]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "max-w-3xl mx-auto px-6 py-16 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl md:text-4xl font-bold mb-8",
				children: "Terms of service"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 text-sm md:text-base text-white/80 leading-relaxed",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tieto podmienky upravujú používanie našej webstránky a základné pravidlá spolupráce pri marketingových a videoprodukčných službách pre zdravotnícke subjekty." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold text-white mt-8",
						children: "Služby"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Poskytujeme marketingovú stratégiu, videoprodukciu, analýzu procesov a konzultácie pre firmy v oblasti healthcare. Konkrétny rozsah a cena sú vždy dohodnuté v samostatnej ponuke." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold text-white mt-8",
						children: "Zodpovednosť za obsah"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Klient zodpovedá za poskytnutie pravdivých informácií o službách a dodržiavanie príslušnej zdravotníckej a reklamnej legislatívy. My pomáhame pripraviť obsah, ktorý je etický, overiteľný a v súlade so zákonom." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold text-white mt-8",
						children: "Kalkulačka a odhady"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kalkulačka na stránke slúži iba ako hrubý orientačný odhad. Presné čísla a možnosti úspor ukáže až individuálna diagnostika a ponuka na mieru." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold text-white mt-8",
						children: "Zmeny podmienok"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Podmienky môžeme časom aktualizovať. Aktuálna verzia je vždy dostupná na tejto stránke. Používaním stránky vyjadrujete súhlas s aktuálnym znením." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-brand-gray text-xs pt-6",
						children: "Posledná aktualizácia: júl 2026."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "inline-flex items-center gap-2 px-6 py-3 rounded-full text-base font-semibold text-white bg-brand-green hover:bg-brand-green-dark transition-colors shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								width: "18",
								height: "18",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19 12H5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 19l-7-7 7-7" })]
							}), "Späť na úvod"]
						})
					})
				]
			})]
		})]
	});
}
//#endregion
export { TermsOfService as component };
