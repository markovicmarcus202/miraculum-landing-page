import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Logo } from "./Logo-Ci4VJEux.mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BuIomDgM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var testimonials = [
	{
		name: "MUDr. Jana Kováčová",
		role: "Klinika Dermalux"
	},
	{
		name: "Peter Novák",
		role: "CEO, MedGroup"
	},
	{
		name: "Lucia Horváthová",
		role: "Marketing, DentaPlus"
	},
	{
		name: "Tomáš Bartoš",
		role: "Riaditeľ, VitaCare"
	}
];
function PlayIcon({ size = 24 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "var(--color-brand-green)",
		strokeWidth: "1.5",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "6 4 20 12 6 20 6 4" })
	});
}
function TestimonialsRow() {
	const trackRef = (0, import_react.useRef)(null);
	const [active, setActive] = (0, import_react.useState)(0);
	const scrollToIndex = (0, import_react.useCallback)((i) => {
		const track = trackRef.current;
		if (!track) return;
		const card = track.children[i];
		if (!card) return;
		const left = card.offsetLeft - (track.clientWidth - card.clientWidth) / 2;
		track.scrollTo({
			left: Math.max(0, left),
			behavior: "smooth"
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const track = trackRef.current;
		if (!track) return;
		let frame = 0;
		const onScroll = () => {
			cancelAnimationFrame(frame);
			frame = requestAnimationFrame(() => {
				const center = track.scrollLeft + track.clientWidth / 2;
				let best = 0;
				let bestDist = Infinity;
				Array.from(track.children).forEach((child, i) => {
					const el = child;
					const c = el.offsetLeft + el.clientWidth / 2;
					const d = Math.abs(c - center);
					if (d < bestDist) {
						bestDist = d;
						best = i;
					}
				});
				setActive(best);
			});
		};
		track.addEventListener("scroll", onScroll, { passive: true });
		requestAnimationFrame(() => scrollToIndex(0));
		return () => {
			track.removeEventListener("scroll", onScroll);
			cancelAnimationFrame(frame);
		};
	}, [scrollToIndex]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: trackRef,
			className: "flex gap-5 overflow-x-auto snap-x snap-mandatory pb-4 -mx-6 px-[calc((100vw-260px)/2)] sm:px-6 md:mx-0 md:px-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
			children: testimonials.map((t, i) => {
				const isActive = i === active;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "snap-center shrink-0 w-[260px] glass glass-hover glass-glow rounded-[16px] transition-all duration-500",
					style: {
						transform: isActive ? "scale(1)" : "scale(0.94)",
						opacity: isActive ? 1 : .6
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full aspect-9/16 flex items-center justify-center relative",
						style: { background: "linear-gradient(160deg, rgba(255,255,255,0.04) 0%, rgba(10,15,30,0.92) 55%, rgba(29,158,117,0.08) 100%)" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayIcon, { size: 56 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
						className: "p-4 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-white font-extrabold text-sm truncate",
									children: t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "my-2 h-px w-8",
									style: { background: "linear-gradient(90deg, var(--color-brand-green-light), var(--color-brand-green))" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-brand-green-light text-xs truncate",
									children: t.role
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "shrink-0 w-12 h-12 rounded-[10px] border flex items-center justify-center",
							style: { borderColor: "rgba(255,255,255,0.12)" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayIcon, {})
						})]
					})]
				}, t.name);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 flex items-center justify-center gap-2.5",
			children: testimonials.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Recenzia ${i + 1}`,
				onClick: () => scrollToIndex(i),
				className: "h-2.5 rounded-full transition-all duration-400",
				style: {
					width: i === active ? 24 : 10,
					background: i === active ? "linear-gradient(90deg, var(--color-brand-green-light), var(--color-brand-green))" : "rgba(255,255,255,0.18)"
				}
			}, t.name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex items-center justify-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Predchádzajúca recenzia",
				onClick: () => scrollToIndex(Math.max(0, active - 1)),
				className: "glass glass-hover w-11 h-11 rounded-full flex items-center justify-center text-brand-green-light",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					width: "18",
					height: "18",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "15 18 9 12 15 6" })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Ďalšia recenzia",
				onClick: () => scrollToIndex(Math.min(testimonials.length - 1, active + 1)),
				className: "glass glass-hover w-11 h-11 rounded-full flex items-center justify-center text-brand-green-light",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					width: "18",
					height: "18",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "9 18 15 12 9 6" })
				})
			})]
		})
	] });
}
function Reveal({ children, delay = 0, className = "", as = "div", y = 24 }) {
	const ref = (0, import_react.useRef)(null);
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
			setVisible(true);
			return;
		}
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setVisible(true);
			return;
		}
		const io = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting) {
					setVisible(true);
					io.unobserve(e.target);
				}
			});
		}, {
			threshold: .15,
			rootMargin: "0px 0px -40px 0px"
		});
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(as, {
		ref,
		className,
		style: {
			opacity: visible ? 1 : 0,
			filter: visible ? "blur(0px)" : "blur(10px)",
			transform: visible ? "translate3d(0,0,0) scale(1)" : `translate3d(0, ${y}px, 0) scale(0.97)`,
			transition: [
				`opacity 900ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`,
				`transform 1100ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`,
				`filter 900ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`
			].join(", "),
			willChange: "opacity, transform, filter"
		},
		children
	});
}
var steps = [
	{
		n: 1,
		title: "Úvodný meeting",
		text: "Ujasníme si ciele, cieľovú skupinu a tón komunikácie vašej značky. Zaujíma nás, čo robíte, komu sa prihovárate a aký výsledok má obsah priniesť."
	},
	{
		n: 2,
		title: "Obsahová stratégia a scenáre",
		text: "Pripravíme stratégiu a konkrétne scenáre pre short-form videá, analyzujeme vaše odvetvie a navrhneme formáty, ktoré majú potenciál zaujať."
	},
	{
		n: 3,
		title: "Natáčanie obsahu",
		text: "Zabezpečíme profesionálnu produkciu aj vedenie pred kamerou, aby videá pôsobili prirodzene a v súlade s vašou značkou."
	},
	{
		n: 4,
		title: "Strih, úprava a publikovanie",
		text: "Materiál spracujeme do dynamických videí optimalizovaných pre jednotlivé platformy a publikujeme na vybraných kanáloch."
	},
	{
		n: 5,
		title: "Správa účtov a optimalizácia",
		text: "Sledujeme výkonnosť a ďalší obsah prispôsobujeme tomu, čo prináša najlepšie výsledky. Cieľom je dlhodobý rast."
	}
];
function ProcessTimeline() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "relative mx-auto max-w-3xl",
		children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
			delay: i * 90,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "relative grid grid-cols-[64px_1fr] gap-5 sm:gap-8 pb-12 last:pb-0",
				children: [
					i < steps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						className: "absolute left-[32px] top-16 bottom-0 w-px",
						style: {
							backgroundColor: "var(--color-brand-green)",
							opacity: .35
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 flex h-16 w-16 items-center justify-center rounded-full border text-lg font-extrabold text-brand-green",
						style: {
							borderColor: "var(--color-brand-border-dark)",
							backgroundColor: "rgba(10,15,30,0.9)"
						},
						children: s.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl md:text-2xl font-extrabold text-white text-pretty",
							children: s.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2.5 text-sm md:text-base text-white/70 leading-relaxed",
							children: s.text
						})]
					})
				]
			})
		}, s.n))
	});
}
var faqs = [
	{
		question: "Aké služby ponúkate?",
		answer: "Ponúkame komplexné marketingové služby zamerané na rast zdravotníckych firiem na sociálnych sieťach: správa sociálnych sietí, tvorba short-form videí, reklamné kampane, obsahová stratégia a scenáre, rast značky a online prítomnosti."
	},
	{
		question: "Prečo by sme mali investovať do videoobsahu v healthcare?",
		answer: "Video vytvára dôveru skôr, ako klient príde do ambulánie. Pacienti sa cez video lepšie zorientujú v procese, poznajú lekára aj prostredie, a sú tak ochotnejší objednať sa alebo využiť vaše služby."
	},
	{
		question: "Čo znamená 'merateľný marketing' v praxi?",
		answer: "Každý krok spájame s číslom: cena za získaného klienta, hodnota objednávky, ušetrené hodiny administratívy. Vidíte presne, čo vám marketing prináša a kde ešte zlepšovať."
	},
	{
		question: "Nahrádzate interný marketingový tím?",
		answer: "Áno. Tvoríme obsah efektívnejšie — s nižšími nákladmi a s merateľnými výsledkami. Spolupracujeme s vaším tímom, dopĺňame ho o to, čo interne nestíhate, a každý krok vyčíslime v konkrétnych číslach."
	},
	{
		question: "Ako dlho trvá výroba jedného videa?",
		answer: "Od konceptu po finálny strih bežne 2–4 týždne. Závisí to od rozsahu — jednoduché rozhovory sú rýchlejšie, komplexnejšie produkcie s viacerými lokáciami trvajú dlhšie. Termín vždy dohodneme dopredu."
	},
	{
		question: "Čo ak ešte nevieme, aký obsah by sme mali tvoriť?",
		answer: "Nechajte to na nás. Prejdeme vaše procesy, konkurenciu a publikum, a navrhneme, ktoré témy a formáty vám prinesú najviac — bez zbytočného plytvania rozpočtom."
	}
];
function Faq() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: faqs.map((item, i) => {
			const isOpen = open === i;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass glass-edge glass-glow rounded-[16px] transition-all duration-300",
				style: { borderColor: isOpen ? "color-mix(in oklab, var(--color-brand-green) 40%, transparent)" : void 0 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(isOpen ? null : i),
					className: "w-full flex items-center justify-between gap-4 p-5 text-left",
					"aria-expanded": isOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm md:text-base font-bold text-white",
						children: item.question
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 w-6 h-6 rounded-full border flex items-center justify-center text-brand-green transition-transform duration-200",
						style: { borderColor: "var(--color-brand-border-dark)" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							width: "14",
							height: "14",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							className: `transition-transform duration-200 ${isOpen ? "rotate-45" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "12",
								y1: "5",
								x2: "12",
								y2: "19"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "5",
								y1: "12",
								x2: "19",
								y2: "12"
							})]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-5 overflow-hidden transition-all duration-300 ease-out",
					style: {
						maxHeight: isOpen ? "320px" : "0px",
						opacity: isOpen ? 1 : 0,
						paddingBottom: isOpen ? "20px" : "0px"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-white/70 leading-relaxed",
						children: item.answer
					})
				})]
			}, i);
		})
	});
}
var EVENT = "miraculum:open-consultation";
/** Opens the 8-step consultation questionnaire from anywhere in the UI. */
function openConsultation(location) {
	if (typeof window === "undefined") return;
	window.dispatchEvent(new CustomEvent(EVENT, { detail: { location } }));
}
function onConsultationOpen(handler) {
	const listener = (e) => {
		const detail = e.detail;
		handler(detail?.location ?? "unknown");
	};
	window.addEventListener(EVENT, listener);
	return () => window.removeEventListener(EVENT, listener);
}
var services = [
	{
		title: "Organic content",
		description: "Reels, TikTok a Shorts, ktoré budujú dôveru a privádzajú pacientov bez platenej reklamy.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "23 7 16 12 23 17 23 7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "1",
			y: "5",
			width: "15",
			height: "14",
			rx: "2",
			ry: "2"
		})] })
	},
	{
		title: "Meta ads",
		description: "Kampane na Facebooku a Instagrame nastavené na objednávky, nie na lajky — s jasným reportom.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 3v18h18" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M7 15l4-4 3 3 5-6" })] })
	},
	{
		title: "Interné systémy",
		description: "Automatizujeme to, čo dnes beží cez Excel, WhatsApp a e-mail — menej ručnej práce, menej chýb.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "3"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" })] })
	},
	{
		title: "CRM na mieru",
		description: "Pacienti, objednávky, faktúry a úlohy na jednom mieste. Pozrite si živú ukážku systému.",
		to: "/crm-ukazka",
		linkLabel: "Zobraziť ukážku CRM →",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "4",
				width: "18",
				height: "16",
				rx: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 9h18" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 13h5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 16h8" })
		] })
	},
	{
		title: "Weby a landing pages",
		description: "Rýchle stránky, ktoré vysvetlia službu a dovedú návštevníka k objednávke — nie len vizitka.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "2",
				y: "3",
				width: "20",
				height: "14",
				rx: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 21h8" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 17v4" })
		] })
	},
	{
		title: "Branding a rebranding",
		description: "Logo, farby, tón komunikácie a vizuálny systém, ktorý vyzerá dôveryhodne v zdravotníctve.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2l3 6 6 1-4.5 4.3 1 6.2-5.5-3-5.5 3 1-6.2L3 9l6-1z" }) })
	}
];
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "sluzby",
		className: "max-w-6xl mx-auto px-6 py-20 md:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				as: "h2",
				className: "text-3xl md:text-4xl font-extrabold mb-10 max-w-2xl text-pretty",
				children: "Aké služby ponúkame?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
				children: services.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 100,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass glass-edge glass-hover glass-glow p-5 h-full flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "28",
								height: "28",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "var(--color-brand-green)",
								strokeWidth: "1.5",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								"aria-hidden": "true",
								children: s.icon
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-base font-extrabold text-white",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-white/70 leading-relaxed",
								children: s.description
							}),
							s.to && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: s.to,
								className: "focus-brand mt-4 inline-flex text-sm font-bold text-brand-green hover:text-brand-green-light transition-colors",
								children: s.linkLabel
							})
						]
					})
				}, s.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 120,
				className: "mt-10 flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => openConsultation("sluzby"),
					className: "btn-liquid btn-shine inline-flex items-center gap-2 rounded-full px-7 py-4 text-sm font-bold text-white",
					children: ["Vyplniť formulár", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "btn-arrow",
						"aria-hidden": "true",
						children: "→"
					})]
				})
			})
		]
	});
}
function ScrollProgress() {
	const [progress, setProgress] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const onScroll = () => {
			const max = document.documentElement.scrollHeight - window.innerHeight;
			setProgress(max > 0 ? window.scrollY / max : 0);
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		window.addEventListener("resize", onScroll);
		return () => {
			window.removeEventListener("scroll", onScroll);
			window.removeEventListener("resize", onScroll);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scroll-progress",
		"aria-hidden": "true",
		style: { transform: `scaleX(${progress})` }
	});
}
var STORAGE_KEY = "miraculum:cta-events";
function trackCta({ cta, location, meta }) {
	const payload = {
		event: "cta_click",
		cta,
		location,
		...meta,
		timestamp: (/* @__PURE__ */ new Date()).toISOString()
	};
	if (typeof window === "undefined") return;
	try {
		const w = window;
		if (Array.isArray(w.dataLayer)) w.dataLayer.push(payload);
		const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
		stored.push(payload);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(stored.slice(-50)));
	} catch {}
}
var questions = [
	{
		id: "services",
		type: "multi",
		question: "Ktoré služby vás zaujímajú?",
		options: [
			"Organic content (Reels, TikTok, Shorts)",
			"Meta ads (Facebook + Instagram)",
			"Interné systémy a automatizácie",
			"CRM na mieru",
			"Web / landing page",
			"Branding alebo rebranding"
		]
	},
	{
		id: "industry",
		type: "single",
		question: "V akom odvetví pôsobíte?",
		options: [
			"Zubná klinika",
			"Estetická medicína",
			"Ambulancia / poliklinika",
			"Wellness a regenerácia",
			"Iné zdravotnícke odvetvie"
		]
	},
	{
		id: "acquisition",
		type: "single",
		question: "Ako dnes najčastejšie získavate nových klientov?",
		options: [
			"Odporúčania a ústna reklama",
			"Sociálne siete",
			"Platená reklama",
			"Google / web",
			"Nemáme to podchytené"
		]
	},
	{
		id: "internal",
		type: "single",
		question: "Ako teraz spravujete klientov a objednávky?",
		options: [
			"Excel a papier",
			"WhatsApp, e-mail a telefón",
			"Máme systém, ale nevyhovuje nám",
			"Máme funkčné CRM"
		]
	},
	{
		id: "budget",
		type: "single",
		question: "Aký mesačný rozpočet na marketing plánujete?",
		options: [
			"do 500 €",
			"500 – 1 500 €",
			"1 500 – 3 000 €",
			"3 000 € a viac",
			"Ešte neviem"
		]
	},
	{
		id: "goal",
		type: "single",
		question: "Čo je pre vás teraz najdôležitejšie?",
		options: [
			"Viac objednávok a klientov",
			"Silnejšia značka a dôvera",
			"Menej administratívy a ručnej práce",
			"Prehľad v číslach a výkonnosti"
		]
	},
	{
		id: "timing",
		type: "single",
		question: "Kedy chcete začať?",
		options: [
			"Čo najskôr",
			"Do mesiaca",
			"Do troch mesiacov",
			"Zisťujem možnosti"
		]
	},
	{
		id: "contact",
		type: "contact",
		question: "Kam sa vám môžeme ozvať?"
	}
];
var contactSchema = objectType({
	name: stringType().trim().nonempty({ message: "Zadajte vaše meno" }).max(100),
	company: stringType().trim().nonempty({ message: "Zadajte názov firmy" }).max(150),
	email: stringType().trim().email({ message: "Zadajte platný e-mail" }).max(255),
	phone: stringType().trim().min(6, { message: "Zadajte platné telefónne číslo" }).max(30).regex(/^[+\d\s()-]+$/, { message: "Telefón môže obsahovať iba čísla a +, -, (, )" })
});
var emptyContact = {
	name: "",
	company: "",
	email: "",
	phone: ""
};
/** Stores the lead locally. Replace with the real CRM call later. */
function submitLead(payload) {
	try {
		const stored = JSON.parse(localStorage.getItem("miraculum:leads") ?? "[]");
		stored.push(payload);
		localStorage.setItem("miraculum:leads", JSON.stringify(stored.slice(-50)));
	} catch {}
}
function ConsultationDialog() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [source, setSource] = (0, import_react.useState)("unknown");
	const [step, setStep] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [contact, setContact] = (0, import_react.useState)(emptyContact);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [done, setDone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => onConsultationOpen((location) => {
		setSource(location);
		setStep(0);
		setDone(false);
		setErrors({});
		setOpen(true);
	}), []);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => e.key === "Escape" && setOpen(false);
		window.addEventListener("keydown", onKey);
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = "";
		};
	}, [open]);
	if (!open) return null;
	const q = questions[step];
	const selected = answers[q.id] ?? [];
	const isLast = step === questions.length - 1;
	const pick = (option) => {
		setAnswers((prev) => {
			const current = prev[q.id] ?? [];
			if (q.type === "multi") return {
				...prev,
				[q.id]: current.includes(option) ? current.filter((o) => o !== option) : [...current, option]
			};
			return {
				...prev,
				[q.id]: [option]
			};
		});
		if (q.type === "single") setTimeout(() => setStep((s) => Math.min(s + 1, questions.length - 1)), 160);
	};
	const submit = () => {
		const parsed = contactSchema.safeParse(contact);
		if (!parsed.success) {
			const next = {};
			for (const issue of parsed.error.issues) next[issue.path[0]] = issue.message;
			setErrors(next);
			return;
		}
		setErrors({});
		trackCta({
			cta: "Dotazník odoslaný",
			location: source
		});
		submitLead({
			...parsed.data,
			answers,
			source,
			timestamp: (/* @__PURE__ */ new Date()).toISOString()
		});
		setDone(true);
	};
	const progress = (step + (done ? 1 : 0)) / questions.length * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-6",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Nezáväzná konzultácia — dotazník",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Zavrieť dotazník",
			onClick: () => setOpen(false),
			className: "absolute inset-0 bg-black/70",
			style: { backdropFilter: "blur(6px)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass glass-edge relative w-full sm:max-w-xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-6 sm:p-8",
			style: { backgroundColor: "rgba(10,15,30,0.94)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-green-light",
						children: done ? "Hotovo" : `Otázka ${step + 1} / ${questions.length}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen(false),
						"aria-label": "Zavrieť",
						className: "text-white/60 hover:text-white transition-colors",
						children: "✕"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-px w-full",
					style: { backgroundColor: "var(--color-brand-border-dark)" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-px transition-all",
						style: {
							width: `${progress}%`,
							backgroundColor: "var(--color-brand-green)"
						}
					})
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-10 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-extrabold text-white",
							children: "Ďakujeme! Ozveme sa vám"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-white/70",
							children: "Vaše odpovede máme. Ozveme sa do 24 hodín na uvedené kontaktné údaje."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen(false),
							className: "btn-liquid mt-8 inline-flex items-center rounded-full px-6 py-3 text-sm font-bold text-white",
							children: "Zavrieť"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-xl sm:text-2xl font-extrabold leading-[1.2] tracking-tight text-white text-pretty",
						children: q.question
					}),
					q.type === "contact" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-4 sm:grid-cols-2",
						children: [
							[
								"name",
								"Vaše meno",
								"Marcus Markovič"
							],
							[
								"company",
								"Názov firmy",
								"Klinika s.r.o."
							],
							[
								"email",
								"Váš e-mail",
								"info@klinika.sk"
							],
							[
								"phone",
								"Telefónne číslo",
								"+421 900 000 000"
							]
						].map(([field, label, placeholder]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white/70 leading-relaxed",
									children: label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: contact[field],
									onChange: (e) => setContact({
										...contact,
										[field]: e.target.value
									}),
									placeholder,
									className: "focus-brand mt-2 w-full rounded-lg border bg-transparent px-3 py-2.5 text-white outline-none",
									style: { borderColor: "var(--color-brand-border-dark)" }
								}),
								errors[field] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs text-brand-green-light",
									children: errors[field]
								})
							]
						}, field))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-2.5",
						children: q.options.map((option) => {
							const active = selected.includes(option);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => pick(option),
								className: "focus-brand flex items-center justify-between gap-3 rounded-xl border px-4 py-3 text-left text-sm text-white/85 transition-colors hover:text-white",
								style: {
									borderColor: active ? "var(--color-brand-green)" : "var(--color-brand-border-dark)",
									backgroundColor: active ? "rgba(29,158,117,0.12)" : "transparent"
								},
								children: [option, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									className: "h-4 w-4 shrink-0 rounded-full border",
									style: {
										borderColor: active ? "var(--color-brand-green)" : "var(--color-brand-border-dark)",
										backgroundColor: active ? "var(--color-brand-green)" : "transparent"
									}
								})]
							}, option);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setStep((s) => Math.max(0, s - 1)),
							disabled: step === 0,
							className: "focus-brand text-sm text-white/60 hover:text-white transition-colors disabled:opacity-30",
							children: "← Späť"
						}), isLast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: submit,
							className: "btn-liquid inline-flex items-center rounded-full px-6 py-3 text-sm font-bold text-white",
							children: "Odoslať dotazník →"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setStep((s) => s + 1),
							disabled: q.type === "multi" && selected.length === 0,
							className: "btn-liquid inline-flex items-center rounded-full px-6 py-3 text-sm font-bold text-white disabled:opacity-40",
							children: "Ďalej →"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs text-brand-gray",
						children: "8 krátkych otázok, zaberie to približne minútu. Nič si tým nezaväzujete."
					})
				] })
			]
		})]
	});
}
var HEADER_OFFSET = 88;
function targetTop(id) {
	const el = document.getElementById(id);
	if (!el) return null;
	return Math.max(el.getBoundingClientRect().top + window.scrollY - HEADER_OFFSET, 0);
}
function maxScroll() {
	return Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
}
/**
* Smooth-scrolls to an in-page anchor, compensating for the sticky header.
* Reveal-on-scroll sections change the document height while scrolling, so we
* keep re-measuring and correcting until the position is stable.
*/
function scrollToId(id) {
	const first = targetTop(id);
	if (first === null) return;
	window.scrollTo({
		top: Math.min(first, maxScroll()),
		behavior: "smooth"
	});
	const start = Date.now();
	let stable = 0;
	const correct = () => {
		const top = targetTop(id);
		if (top === null) return;
		const want = Math.min(top, maxScroll());
		if (Math.abs(window.scrollY - want) <= 2) stable += 1;
		else {
			stable = 0;
			window.scrollTo({
				top: want,
				behavior: "auto"
			});
		}
		if (stable < 3 && Date.now() - start < 2500) requestAnimationFrame(correct);
	};
	setTimeout(() => requestAnimationFrame(correct), 550);
}
function handleAnchorClick(e, href) {
	if (!href.startsWith("#")) return;
	e.preventDefault();
	scrollToId(href.slice(1));
	if (window.history.replaceState) window.history.replaceState(null, "", href);
}
var navLinks = [
	{
		href: "#domov",
		label: "Domov"
	},
	{
		href: "#o-nas",
		label: "O nás"
	},
	{
		href: "#sluzby",
		label: "Služby"
	},
	{
		href: "#proces",
		label: "Proces"
	},
	{
		href: "#recenzie",
		label: "Recenzie"
	},
	{
		href: "#kontakt",
		label: "Kontakt"
	}
];
var values = [
	{
		title: "Merateľné výsledky",
		text: "Každé zlepšenie vyčíslime v eurách, nie v pocitoch.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 3v18h18" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M7 15l4-4 3 3 5-6" })] })
	},
	{
		title: "Zameranie na healthcare",
		text: "Rozumieme klinikám, ambulanciám a zdravotníckym firmám.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 21s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9z" }) })
	},
	{
		title: "Bez zbytočnej práce",
		text: "Automatizujeme to, čo teraz beží cez Excel, WhatsApp a e-mail.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "3"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" })] })
	},
	{
		title: "Video, ktoré predáva",
		text: "Produkcia, ktorá privádza klientov, nie len zbiera lajky.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "23 7 16 12 23 17 23 7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "1",
			y: "5",
			width: "15",
			height: "14",
			rx: "2",
			ry: "2"
		})] })
	}
];
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "domov",
		className: "relative min-h-screen bg-brand-navy text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollProgress, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsultationDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aurora",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-global",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grain",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
						className: "sticky top-0 z-40 px-3 pt-3 sm:px-5 sm:pt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-6xl mx-auto rounded-full border px-3 sm:px-5 h-14 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 md:flex md:justify-between",
							style: {
								backgroundColor: "rgba(10,15,30,0.62)",
								borderColor: "rgba(255,255,255,0.09)",
								backdropFilter: "blur(22px) saturate(160%)"
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#domov",
									onClick: (e) => handleAnchorClick(e, "#domov"),
									className: "flex items-center gap-2 text-white pl-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
										size: 34,
										className: "text-white"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
									className: "hidden md:flex items-center gap-6 text-[13px] text-white/70",
									children: navLinks.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: l.href,
										onClick: (e) => handleAnchorClick(e, l.href),
										className: "focus-brand hover:text-white transition-colors",
										children: l.label
									}, l.href))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										trackCta({
											cta: "Nezáväzná konzultácia",
											location: "header"
										});
										openConsultation("header");
									},
									className: "btn-liquid inline-flex shrink-0 items-center rounded-full px-4 py-2 text-[13px] font-bold text-white",
									children: "Nezáväzná konzultácia"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative max-w-6xl mx-auto px-6 pt-16 pb-16 md:pt-28 md:pb-24",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								as: "h1",
								delay: 90,
								className: "display text-[2.6rem] md:text-[4.75rem] font-black leading-[1.06] tracking-tight max-w-4xl text-pretty text-shimmer",
								children: "Máte tím aj klientov, ale strácate čas a peniaze na ručnom marketingu?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
								delay: 220,
								className: "mt-9 flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										trackCta({
											cta: "Vyplniť formulár",
											location: "hero"
										});
										openConsultation("hero");
									},
									className: "btn-liquid btn-shine inline-flex items-center justify-center gap-2 rounded-full px-7 py-4 text-sm font-bold text-white",
									children: ["Vyplniť formulár", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "btn-arrow",
										"aria-hidden": "true",
										children: "→"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#sluzby",
									onClick: (e) => handleAnchorClick(e, "#sluzby"),
									className: "focus-brand inline-flex items-center justify-center rounded-full border px-6 py-4 text-sm font-bold text-white/85 hover:text-white transition-colors",
									style: { borderColor: "var(--color-brand-border-dark)" },
									children: "Pozrieť služby"
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "recenzie",
						className: "max-w-6xl mx-auto px-6 py-20 md:py-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								className: "mb-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl md:text-4xl font-extrabold text-pretty",
									children: "Čo hovoria ľudia, s ktorými sme pracovali?"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 120,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestimonialsRow, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 200,
								className: "mt-10 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										trackCta({
											cta: "Vyplniť formulár",
											location: "recenzie"
										});
										openConsultation("recenzie");
									},
									className: "btn-liquid inline-flex items-center gap-2 rounded-full px-7 py-4 text-sm font-bold text-white",
									children: ["Chcem podobné výsledky", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "btn-arrow",
										"aria-hidden": "true",
										children: "→"
									})]
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "o-nas",
						className: "py-20 md:py-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-w-6xl mx-auto px-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass glass-edge glass-glow p-6 sm:p-8 md:p-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-[0.2em] uppercase text-brand-green-light mb-4",
										children: "O nás"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl md:text-3xl font-extrabold text-white max-w-3xl text-pretty",
										children: "Malý tím, s ktorým budete v priamom kontakte."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 max-w-3xl text-sm md:text-base text-white/70 leading-relaxed",
										children: "Nie sme veľká agentúra s desiatkami klientov na jedného človeka. Sme tím, ktorý pozná váš biznis, dvíha telefón a rieši veci priamo s vami — od prvého rozhovoru až po výsledky, ktoré si spolu odsledujeme."
									})
								]
							}) })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "max-w-6xl mx-auto px-6 pb-20 md:pb-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							as: "h2",
							className: "text-3xl md:text-4xl font-extrabold mb-10 max-w-2xl text-pretty",
							children: "V čom sme iní?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
							children: values.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: i * 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "glass glass-edge glass-hover glass-glow p-5 h-full",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											width: "28",
											height: "28",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "var(--color-brand-green)",
											strokeWidth: "1.5",
											strokeLinecap: "round",
											strokeLinejoin: "round",
											"aria-hidden": "true",
											children: v.icon
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-4 text-base font-extrabold text-white",
											children: v.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-white/70 leading-relaxed",
											children: v.text
										})
									]
								})
							}, v.title))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "proces",
						className: "max-w-6xl mx-auto px-6 py-20 md:py-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								as: "h2",
								className: "text-3xl md:text-4xl font-extrabold mb-12 max-w-2xl text-pretty",
								children: "Ako to celé prebieha?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessTimeline, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 150,
								className: "mt-12 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										trackCta({
											cta: "Vyplniť formulár",
											location: "proces"
										});
										openConsultation("proces");
									},
									className: "btn-liquid btn-shine inline-flex items-center gap-2 rounded-full px-7 py-4 text-sm font-bold text-white",
									children: ["Vyplniť formulár", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "btn-arrow",
										"aria-hidden": "true",
										children: "→"
									})]
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "faq",
						className: "max-w-6xl mx-auto px-6 py-20 md:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							as: "h2",
							className: "text-3xl md:text-4xl font-extrabold mb-10 max-w-2xl text-pretty",
							children: "FAQ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 120,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "max-w-6xl mx-auto px-6 pb-20 md:pb-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass glass-edge glass-glow p-8 md:p-12 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-2xl md:text-3xl font-extrabold text-white text-pretty",
									children: "Zistite za minútu, čo vo vašom marketingu opraviť ako prvé."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm md:text-base text-white/70",
									children: "8 krátkych otázok. Ozveme sa do 24 hodín s konkrétnym návrhom."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										trackCta({
											cta: "Nezáväzná konzultácia",
											location: "final-cta"
										});
										openConsultation("final-cta");
									},
									className: "btn-liquid btn-shine mt-8 inline-flex items-center gap-2 rounded-full px-8 py-4 text-sm font-bold text-white",
									children: ["Nezáväzná konzultácia", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "btn-arrow",
										"aria-hidden": "true",
										children: "→"
									})]
								})
							]
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						id: "kontakt",
						className: "border-t",
						style: { borderColor: "var(--color-brand-border-dark)" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-6xl mx-auto px-6 py-12 grid gap-10 md:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2 text-white",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
										size: 28,
										className: "text-white"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm text-brand-gray max-w-xs",
									children: "Marketing a videoprodukcia pre healthcare — merateľné výsledky, menej zbytočnej práce."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-[0.18em] uppercase text-brand-green-light mb-4",
									children: "Kontakt"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "space-y-3 text-sm text-white/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										"Marcus Markovič",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "tel:+421910677657",
											className: "text-brand-green hover:text-brand-green-light transition-colors",
											children: "+421 910 677 657"
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "mailto:markovicmarcus202@gmail.com",
											className: "text-brand-green hover:text-brand-green-light transition-colors",
											children: "markovicmarcus202@gmail.com"
										}) })
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										"Šimon Stančík",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "tel:+421910557401",
											className: "text-brand-green hover:text-brand-green-light transition-colors",
											children: "+421 910 557 401"
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "mailto:simon.stancik.sk@gmail.com",
											className: "text-brand-green hover:text-brand-green-light transition-colors",
											children: "simon.stancik.sk@gmail.com"
										}) })
									] })]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-[0.18em] uppercase text-brand-green-light mb-4",
									children: "Navigácia"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2 text-sm text-white/80",
									children: navLinks.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: l.href,
										onClick: (e) => handleAnchorClick(e, l.href),
										className: "hover:text-brand-green-light transition-colors",
										children: l.label
									}) }, l.href))
								})] })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-t",
							style: { borderColor: "var(--color-brand-border-dark)" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-6xl mx-auto px-6 py-6 flex flex-col sm:flex-row gap-3 sm:gap-6 justify-between items-start sm:items-center text-xs text-brand-gray",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"© ",
									(/* @__PURE__ */ new Date()).getFullYear(),
									" Miraculum."
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-4 sm:gap-6 items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/privacy-policy",
										className: "hover:text-brand-green-light transition-colors",
										children: "Privacy policy"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/terms-of-service",
										className: "hover:text-brand-green-light transition-colors",
										children: "Terms of service"
									})]
								})]
							})
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Landing as component };
