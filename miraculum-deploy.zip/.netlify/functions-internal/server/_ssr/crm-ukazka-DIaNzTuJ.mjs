import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as CalendarCheck, C as History, D as Check, E as Eye, O as Calendar, S as Image, T as FileText, _ as MessageCircle, a as TrendingUp, b as LayoutDashboard, c as Sparkles, d as Search, f as Receipt, g as PhoneCall, h as Phone, i as Upload, k as CalendarPlus, l as ShieldCheck, m as Play, n as Wallet, o as Target, p as Plus, r as Users, s as Stethoscope, t as X, u as Share2, v as Megaphone, w as Heart, x as Inbox, y as ListChecks } from "../_libs/lucide-react.mjs";
import { a as Tooltip, i as ResponsiveContainer, n as XAxis, r as Bar, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/crm-ukazka-DIaNzTuJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STAGES = [
	"Nový dopyt",
	"Kontaktovaný",
	"Konzultácia naplánovaná",
	"Pacient"
];
var STAGE_STYLE = {
	"Nový dopyt": {
		color: "#5B7FA6",
		bg: "#EAF0F7"
	},
	"Kontaktovaný": {
		color: "#B8791F",
		bg: "#FBF0DD"
	},
	"Konzultácia naplánovaná": {
		color: "#3E8F76",
		bg: "#E4F3EE"
	},
	"Pacient": {
		color: "#12403E",
		bg: "#DCE8E5"
	}
};
var INVOICE_STYLE = {
	"Zaplatená": {
		color: "#3E8F76",
		bg: "#E4F3EE"
	},
	"Čaká na úhradu": {
		color: "#B8791F",
		bg: "#FBF0DD"
	},
	"Po splatnosti": {
		color: "#B84A3E",
		bg: "#FBE4E1"
	}
};
var EVENT_META = {
	dopyt: {
		icon: Inbox,
		color: "#5B7FA6",
		bg: "#EAF0F7"
	},
	kontakt: {
		icon: PhoneCall,
		color: "#B8791F",
		bg: "#FBF0DD"
	},
	konzultacia: {
		icon: CalendarCheck,
		color: "#3E8F76",
		bg: "#E4F3EE"
	},
	rtg: {
		icon: Image,
		color: "#5C716C",
		bg: "#EFF4F3"
	},
	zakrok: {
		icon: Stethoscope,
		color: "#12403E",
		bg: "#DCE8E5"
	},
	faktura: {
		icon: Receipt,
		color: "#C98A2E",
		bg: "#F3E4C8"
	},
	poznamka: {
		icon: FileText,
		color: "#8A9C97",
		bg: "#F5F8F7"
	}
};
var EVENT_DETAIL_META = {
	dopyt: {
		fields: [
			["Zdroj dopytu", "Web formulár / telefón / sociálne siete"],
			["Zaznamenal", "Recepcia"],
			["Ďalší krok", "Telefonický kontakt do 24 hodín"]
		],
		dropzone: false
	},
	kontakt: {
		fields: [
			["Spôsob kontaktu", "Telefonicky"],
			["Výsledok hovoru", "Dohodnutý ďalší krok"],
			["Zaznamenal", "Recepcia"]
		],
		dropzone: false
	},
	konzultacia: {
		fields: [
			["Lekár", "MUDr. Katarína Novotná"],
			["Očakávané trvanie", "30 min"],
			["Miestnosť", "Ambulancia 1"]
		],
		dropzone: true,
		dropLabel: "Priložiť súhlas alebo poznámky z konzultácie"
	},
	rtg: {
		fields: [["Vyžiadal", "Ošetrujúci lekár"], ["Zariadenie", "Interné RTG kliniky"]],
		dropzone: true,
		dropLabel: "Priložiť RTG snímok (DICOM / JPG / PDF)"
	},
	zakrok: {
		fields: [["Vykonal", "Ošetrujúci lekár"], ["Použitý materiál", "Podľa zdravotnej dokumentácie"]],
		dropzone: true,
		dropLabel: "Priložiť správu zo zákroku"
	},
	faktura: {
		fields: [],
		dropzone: false,
		linkToInvoice: true
	},
	poznamka: {
		fields: [],
		dropzone: false
	}
};
var SERVICES = [
	"Implantáty",
	"Zubná hygiena",
	"Rovnátka",
	"Estetická stomatológia",
	"Vstupná prehliadka"
];
var DOCTORS = ["MUDr. Katarína Novotná", "MUDr. Roman Beňo"];
var BOOKING_SLOTS = {
	"MUDr. Katarína Novotná": [
		"Po 9:00",
		"Po 11:00",
		"St 10:00",
		"Št 14:00"
	],
	"MUDr. Roman Beňo": [
		"Ut 9:00",
		"Ut 13:00",
		"St 15:00",
		"Pi 10:00"
	]
};
var SUPPLIER = {
	name: "Template Klinika s.r.o.",
	address: "Ukážková 1, 811 01 Bratislava",
	ico: "00 000 000",
	dic: "2000000000",
	icDph: "SK2000000000",
	iban: "SK00 0000 0000 0000 0000 0000"
};
var TAB_INTRO = {
	dashboard: "Toto je Prehľad — rýchly pohľad na to, čo sa v klinike deje tento týždeň: nové dopyty, konzultácie a ich vývoj v čase. V reálnom nasadení má každý člen tímu svoj vlastný prístupový kód a CRM presne podľa toho, čo potrebuje — recepcia, lekár aj majiteľ majú svoj pohľad.",
	patients: "Tu vidíte cestu každého pacienta — od prvého dopytu až po pravidelnú starostlivosť. Kliknutím na kartu otvoríte celý detail vrátane RTG a dokumentácie.",
	calendar: "Týždenný prehľad termínov. Kliknutím na termín sa dostanete priamo k danému pacientovi.",
	tasks: "Jednoduchý zoznam vecí na vybavenie — objednávky materiálu, papierovanie, čokoľvek prevádzkové.",
	archive: "Zadajte meno pacienta a uvidíte celú jeho históriu na jednom mieste — dopyty, snímky, zákroky aj faktúry.",
	booking: "Verejná rezervačná stránka pre recepciu aj pacientov — vyberiete službu, lekára a voľný termín, systém urobí zvyšok.",
	content: "Prehľad toho, ako funguje váš organický obsah — dosah, zobrazenia aj najlepšie príspevky.",
	plan: "Mesačný prehľad podľa služby — kde rastiete, kde je priestor na zlepšenie, a konkrétne kroky ako to dosiahnuť.",
	finance: "Peniaze na jednom mieste — tržby, priemerná hodnota pacienta aj to, čo ešte len príde.",
	invoices: "Platby od pacientov aj platby, ktoré robíte vy sami (materiál, laboratórium) — prehľadne oddelené na jednom mieste."
};
var INITIAL_PATIENTS = [
	{
		id: 1,
		name: "Jana Kováčová",
		phone: "+421 905 111 222",
		service: "Implantáty",
		stage: "Nový dopyt",
		note: "28. 7.",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: false
			},
			{
				label: "Vstupný RTG snímok",
				done: false
			},
			{
				label: "Preukaz poistenca",
				done: false
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: false
			}
		],
		xrays: [],
		notes: "Prvý kontakt cez formulár na webe. Zatiaľ nekontaktovaná."
	},
	{
		id: 2,
		name: "Martin Sedlák",
		phone: "+421 903 222 333",
		service: "Vstupná prehliadka",
		stage: "Nový dopyt",
		note: "28. 7.",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: false
			},
			{
				label: "Vstupný RTG snímok",
				done: false
			},
			{
				label: "Preukaz poistenca",
				done: false
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: false
			}
		],
		xrays: [],
		notes: "Dopyt cez telefón, žiada termín v poobedňajších hodinách."
	},
	{
		id: 3,
		name: "Andrea Šimková",
		phone: "+421 910 333 444",
		service: "Rovnátka",
		stage: "Nový dopyt",
		note: "27. 7.",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: false
			},
			{
				label: "Vstupný RTG snímok",
				done: false
			},
			{
				label: "Preukaz poistenca",
				done: false
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: false
			}
		],
		xrays: [],
		notes: "Záujem po zhliadnutí Instagram videa o rovnátkach."
	},
	{
		id: 4,
		name: "Eva Horváthová",
		phone: "+421 907 444 555",
		service: "Rovnátka",
		stage: "Kontaktovaný",
		note: "26. 7.",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: true
			},
			{
				label: "Vstupný RTG snímok",
				done: false
			},
			{
				label: "Preukaz poistenca",
				done: false
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: false
			}
		],
		xrays: [],
		notes: "Čaká na termín, uprednostňuje utorky."
	},
	{
		id: 5,
		name: "Peter Malík",
		phone: "+421 911 555 666",
		service: "Implantáty",
		stage: "Kontaktovaný",
		note: "25. 7.",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: true
			},
			{
				label: "Vstupný RTG snímok",
				done: true
			},
			{
				label: "Preukaz poistenca",
				done: false
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: false
			}
		],
		xrays: [{
			label: "Panoramatický RTG",
			date: "22. 7. 2026"
		}],
		notes: "Platba za predchádzajúcu faktúru je po splatnosti — pripomenúť."
	},
	{
		id: 6,
		name: "Lucia Bartošová",
		phone: "+421 904 666 777",
		service: "Estetická stomatológia",
		stage: "Konzultácia naplánovaná",
		note: "30. 7. o 9:00",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: true
			},
			{
				label: "Vstupný RTG snímok",
				done: true
			},
			{
				label: "Preukaz poistenca",
				done: true
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: false
			}
		],
		xrays: [{
			label: "Panoramatický RTG",
			date: "20. 7. 2026"
		}],
		notes: "Konzultácia potvrdená, poslať pripomienku deň vopred."
	},
	{
		id: 7,
		name: "Tomáš Novák",
		phone: "+421 908 777 888",
		service: "Implantáty",
		stage: "Konzultácia naplánovaná",
		note: "31. 7. o 11:00",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: true
			},
			{
				label: "Vstupný RTG snímok",
				done: true
			},
			{
				label: "Preukaz poistenca",
				done: true
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: true
			}
		],
		xrays: [{
			label: "CBCT sken",
			date: "18. 7. 2026"
		}],
		notes: "Zaujíma sa aj o bielenie zubov po dokončení implantátu."
	},
	{
		id: 8,
		name: "Zuzana Krajčovičová",
		phone: "+421 902 888 999",
		service: "Zubná hygiena",
		stage: "Pacient",
		note: "pacientka od 3/2026",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: true
			},
			{
				label: "Vstupný RTG snímok",
				done: true
			},
			{
				label: "Preukaz poistenca",
				done: true
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: true
			}
		],
		xrays: [{
			label: "Panoramatický RTG",
			date: "3. 3. 2026"
		}, {
			label: "Kontrolný RTG",
			date: "10. 6. 2026"
		}],
		notes: "Pravidelná hygiena každých 6 mesiacov, ďalší termín november 2026."
	},
	{
		id: 9,
		name: "Ján Vareha",
		phone: "+421 918 999 000",
		service: "Implantáty",
		stage: "Pacient",
		note: "pacient od 1/2026",
		checklist: [
			{
				label: "Odporúčanie od lekára",
				done: true
			},
			{
				label: "Vstupný RTG snímok",
				done: true
			},
			{
				label: "Preukaz poistenca",
				done: true
			},
			{
				label: "Podpísaný súhlas s ošetrením",
				done: true
			}
		],
		xrays: [{
			label: "CBCT sken",
			date: "5. 1. 2026"
		}, {
			label: "Kontrolný RTG",
			date: "15. 5. 2026"
		}],
		notes: "Implantát zavedený, hojenie prebieha bez komplikácií."
	}
];
var TIMELINES = {
	"Jana Kováčová": [{
		date: "28. 7. 2026",
		type: "dopyt",
		label: "Dopyt prijatý cez web formulár — záujem o implantáty"
	}],
	"Martin Sedlák": [{
		date: "28. 7. 2026",
		type: "dopyt",
		label: "Dopyt prijatý telefonicky — vstupná prehliadka"
	}],
	"Andrea Šimková": [{
		date: "27. 7. 2026",
		type: "dopyt",
		label: "Dopyt prijatý — reakcia na Instagram video o rovnátkach"
	}],
	"Eva Horváthová": [{
		date: "24. 7. 2026",
		type: "dopyt",
		label: "Dopyt prijatý — záujem o rovnátka"
	}, {
		date: "26. 7. 2026",
		type: "kontakt",
		label: "Telefonicky kontaktovaná, čaká sa na termín"
	}],
	"Peter Malík": [
		{
			date: "10. 7. 2026",
			type: "faktura",
			label: "Faktúra F2026-0145 — 1 200 € (predchádzajúce ošetrenie, po splatnosti)"
		},
		{
			date: "20. 7. 2026",
			type: "dopyt",
			label: "Nový dopyt — záujem o implantáty"
		},
		{
			date: "22. 7. 2026",
			type: "rtg",
			label: "Nahratý panoramatický RTG snímok"
		},
		{
			date: "25. 7. 2026",
			type: "kontakt",
			label: "Kontaktovaný, čaká sa na potvrdenie termínu"
		}
	],
	"Lucia Bartošová": [
		{
			date: "18. 7. 2026",
			type: "dopyt",
			label: "Dopyt — estetická stomatológia"
		},
		{
			date: "20. 7. 2026",
			type: "rtg",
			label: "Nahratý panoramatický RTG snímok"
		},
		{
			date: "22. 7. 2026",
			type: "kontakt",
			label: "Kontaktovaná, termín dohodnutý"
		},
		{
			date: "25. 7. 2026",
			type: "faktura",
			label: "Faktúra F2026-0144 — 420 € (čaká na úhradu)"
		},
		{
			date: "30. 7. 2026",
			type: "konzultacia",
			label: "Naplánovaná konzultácia o 9:00"
		}
	],
	"Tomáš Novák": [
		{
			date: "12. 7. 2026",
			type: "dopyt",
			label: "Dopyt — implantáty"
		},
		{
			date: "18. 7. 2026",
			type: "rtg",
			label: "Nahratý CBCT sken"
		},
		{
			date: "20. 7. 2026",
			type: "kontakt",
			label: "Kontaktovaný, prejavil záujem aj o bielenie zubov"
		},
		{
			date: "27. 7. 2026",
			type: "faktura",
			label: "Faktúra F2026-0146 — 680 € (čaká na úhradu)"
		},
		{
			date: "31. 7. 2026",
			type: "konzultacia",
			label: "Naplánovaná konzultácia o 11:00"
		}
	],
	"Zuzana Krajčovičová": [
		{
			date: "3. 3. 2026",
			type: "dopyt",
			label: "Dopyt — zubná hygiena"
		},
		{
			date: "3. 3. 2026",
			type: "rtg",
			label: "Nahratý panoramatický RTG snímok"
		},
		{
			date: "10. 3. 2026",
			type: "zakrok",
			label: "Vykonaná vstupná hygiena chrupu"
		},
		{
			date: "10. 6. 2026",
			type: "rtg",
			label: "Kontrolný RTG snímok"
		},
		{
			date: "10. 6. 2026",
			type: "zakrok",
			label: "Kontrolná hygiena chrupu"
		},
		{
			date: "20. 7. 2026",
			type: "faktura",
			label: "Faktúra F2026-0142 — 85 € (zaplatená)"
		},
		{
			date: "",
			type: "poznamka",
			label: "Ďalší termín naplánovaný na november 2026"
		}
	],
	"Ján Vareha": [
		{
			date: "5. 1. 2026",
			type: "dopyt",
			label: "Dopyt — implantáty"
		},
		{
			date: "5. 1. 2026",
			type: "rtg",
			label: "Nahratý CBCT sken"
		},
		{
			date: "20. 1. 2026",
			type: "zakrok",
			label: "Zavedenie implantátu"
		},
		{
			date: "15. 5. 2026",
			type: "rtg",
			label: "Kontrolný RTG snímok"
		},
		{
			date: "15. 5. 2026",
			type: "zakrok",
			label: "Kontrola hojenia"
		},
		{
			date: "22. 7. 2026",
			type: "faktura",
			label: "Faktúra F2026-0143 — 950 € (zaplatená)"
		},
		{
			date: "",
			type: "poznamka",
			label: "Hojenie prebieha bez komplikácií"
		}
	]
};
var WEEKLY = [
	{
		week: "1",
		dopyty: 6
	},
	{
		week: "2",
		dopyty: 8
	},
	{
		week: "3",
		dopyty: 7
	},
	{
		week: "4",
		dopyty: 11
	},
	{
		week: "5",
		dopyty: 9
	},
	{
		week: "6",
		dopyty: 13
	},
	{
		week: "7",
		dopyty: 12
	},
	{
		week: "8",
		dopyty: 14
	}
];
var CONTENT_WEEKLY = [
	{
		week: "1",
		dosah: 9200
	},
	{
		week: "2",
		dosah: 11400
	},
	{
		week: "3",
		dosah: 10100
	},
	{
		week: "4",
		dosah: 14800
	},
	{
		week: "5",
		dosah: 13200
	},
	{
		week: "6",
		dosah: 18900
	},
	{
		week: "7",
		dosah: 21300
	},
	{
		week: "8",
		dosah: 24800
	}
];
var REVENUE_BY_SERVICE = [
	{
		service: "Implantáty",
		trzby: 8400
	},
	{
		service: "Rovnátka",
		trzby: 3200
	},
	{
		service: "Zubná hygiena",
		trzby: 1100
	},
	{
		service: "Estetika",
		trzby: 2600
	},
	{
		service: "Prehliadka",
		trzby: 400
	}
];
var SERVICE_PLAN = [
	{
		service: "Implantáty",
		count: 9,
		trend: 12,
		note: "Funguje veľmi dobre — pokračovať v aktuálnom obsahu a reklame."
	},
	{
		service: "Vstupná prehliadka",
		count: 11,
		trend: 18,
		note: "Silný vstupný kanál do lievika, udržať frekvenciu obsahu."
	},
	{
		service: "Zubná hygiena",
		count: 14,
		trend: 5,
		note: "Stabilné — vhodné na pripomienkové kampane (6-mesačné kontroly)."
	},
	{
		service: "Rovnátka",
		count: 3,
		trend: -8,
		note: "Pokles oproti minulému mesiacu — odporúčame 2 nové videá o priebehu liečby."
	},
	{
		service: "Estetická stomatológia",
		count: 2,
		trend: -20,
		note: "Najslabšia služba tento mesiac — potrebuje cielenú pozornosť."
	}
];
var PLAN_RECOMMENDATIONS = [
	"Reel nápad: 3 prípady „pred a po\" za posledný mesiac, trendy hudba, text „Toto sa dá zmeniť za jednu návštevu.\"",
	"Doplnok pre callera: pri každom dopyte sa opýtať aj „Riešili ste niekedy aj estetiku úsmevu?\" — cross-sell do existujúcich dopytov.",
	"Reklama: cielenie 5–10 km okolo kliniky, vek 25–45, záujem beauty/estetika, rozpočet cca 15 €/deň na 2 týždne."
];
var INITIAL_INVOICES = [
	{
		id: 1,
		number: "F2026-0142",
		patient: "Zuzana Krajčovičová",
		companyName: "Zuzana Krajčovičová",
		ico: "",
		dic: "",
		vatPayer: false,
		service: "Zubná hygiena",
		amount: 85,
		date: "20. 7. 2026",
		status: "Zaplatená"
	},
	{
		id: 2,
		number: "F2026-0143",
		patient: "Ján Vareha",
		companyName: "Ján Vareha",
		ico: "",
		dic: "",
		vatPayer: false,
		service: "Implantát — zavedenie",
		amount: 950,
		date: "22. 7. 2026",
		status: "Zaplatená"
	},
	{
		id: 3,
		number: "F2026-0144",
		patient: "Lucia Bartošová",
		companyName: "Lucia Bartošová",
		ico: "",
		dic: "",
		vatPayer: false,
		service: "Estetická stomatológia — konzultácia",
		amount: 420,
		date: "25. 7. 2026",
		status: "Čaká na úhradu"
	},
	{
		id: 4,
		number: "F2026-0145",
		patient: "Peter Malík",
		companyName: "Peter Malík",
		ico: "",
		dic: "",
		vatPayer: false,
		service: "Implantáty — vstupné ošetrenie",
		amount: 1200,
		date: "10. 7. 2026",
		status: "Po splatnosti"
	},
	{
		id: 5,
		number: "F2026-0146",
		patient: "Tomáš Novák",
		companyName: "Tomáš Novák",
		ico: "",
		dic: "",
		vatPayer: false,
		service: "Implantáty — konzultácia",
		amount: 680,
		date: "27. 7. 2026",
		status: "Čaká na úhradu"
	}
];
var RECEIVED_INVOICES = [
	{
		id: 1,
		number: "D2026-088",
		supplier: "Dentálne laboratórium Novák s.r.o.",
		amount: 640,
		date: "18. 7. 2026",
		status: "Čaká na úhradu"
	},
	{
		id: 2,
		number: "D2026-089",
		supplier: "MedMat s.r.o. — zdravotnícky materiál",
		amount: 310,
		date: "15. 7. 2026",
		status: "Zaplatená"
	},
	{
		id: 3,
		number: "M2026-014",
		supplier: "Miraculum — marketing a obsah",
		amount: 890,
		date: "1. 7. 2026",
		status: "Zaplatená"
	},
	{
		id: 4,
		number: "D2026-090",
		supplier: "Zubotechnika Šulek",
		amount: 480,
		date: "22. 7. 2026",
		status: "Po splatnosti"
	}
];
var APPOINTMENTS = [
	{
		day: "Po",
		time: "9:00",
		name: "Lucia Bartošová",
		service: "Estetická stomatológia"
	},
	{
		day: "Po",
		time: "13:00",
		name: "Ján Vareha",
		service: "Kontrola — implantát"
	},
	{
		day: "Ut",
		time: "10:00",
		name: "Tomáš Novák",
		service: "Konzultácia — implantáty"
	},
	{
		day: "St",
		time: "9:00",
		name: "Zuzana Krajčovičová",
		service: "Zubná hygiena"
	},
	{
		day: "St",
		time: "14:00",
		name: "Nový pacient",
		service: "Konzultácia — rovnátka"
	},
	{
		day: "Št",
		time: "11:00",
		name: "Peter Malík",
		service: "Implantáty — 2. fáza"
	},
	{
		day: "Pi",
		time: "9:00",
		name: "Andrea Šimková",
		service: "Vstupná konzultácia"
	}
];
var DAYS = [
	"Po",
	"Ut",
	"St",
	"Št",
	"Pi"
];
var HOURS = [
	"8:00",
	"9:00",
	"10:00",
	"11:00",
	"12:00",
	"13:00",
	"14:00",
	"15:00"
];
function formatSk(d) {
	return `${d.getDate()}. ${d.getMonth() + 1}. ${d.getFullYear()}`;
}
function getWeekRange(d) {
	const day = (d.getDay() + 6) % 7;
	const monday = new Date(d);
	monday.setDate(d.getDate() - day);
	const sunday = new Date(monday);
	sunday.setDate(monday.getDate() + 6);
	return `${monday.getDate()}. ${monday.getMonth() + 1}. – ${sunday.getDate()}. ${sunday.getMonth() + 1}.`;
}
function AnimatedNumber({ value, suffix = "", duration = 800, decimals = 0 }) {
	const [display, setDisplay] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let raf;
		let start = null;
		function step(ts) {
			if (!start) start = ts;
			const progress = Math.min((ts - start) / duration, 1);
			const eased = 1 - Math.pow(1 - progress, 3);
			setDisplay(value * eased);
			if (progress < 1) raf = requestAnimationFrame(step);
		}
		raf = requestAnimationFrame(step);
		return () => cancelAnimationFrame(raf);
	}, [value, duration]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [display.toLocaleString("sk-SK", {
		minimumFractionDigits: decimals,
		maximumFractionDigits: decimals
	}), suffix] });
}
var STYLE = `


.tk-root { font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; background: #F5F8F7; color: #142420; min-height: 100vh; display: flex; }
.tk-root * { box-sizing: border-box; }
.tk-mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.tk-display { font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; }

.tk-sidebar { width: 240px; flex-shrink: 0; background: #FFFFFF; border-right: 1px solid #E2E9E7; padding: 24px 16px; display: flex; flex-direction: column; gap: 16px; }
.tk-logo-row { display: flex; align-items: center; gap: 10px; padding: 0 8px; }
.tk-logo-mark { width: 38px; height: 38px; border-radius: 12px; background: linear-gradient(135deg, #17534F, #0D302E); color: #F5F8F7; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 4px 12px -2px rgba(18,64,62,0.4); }
.tk-logo-text { line-height: 1.15; }
.tk-logo-text .name { font-weight: 600; font-size: 15px; }
.tk-badge { display: inline-flex; align-items: center; gap: 5px; font-size: 10.5px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; color: #B8791F; background: #FBF0DD; border: 1px solid #F0DDB2; padding: 4px 8px; border-radius: 6px; margin: 8px 8px 0; }
.tk-tour-banner { background: #E4F3EE; border: 1px solid #C7E2D8; border-radius: 10px; padding: 9px 10px; font-size: 11.5px; color: #12403E; line-height: 1.4; display: flex; gap: 6px; align-items: flex-start; margin: 0 8px; }
.tk-tour-banner button { background: none; border: none; color: #3E8F76; cursor: pointer; font-size: 13px; flex-shrink: 0; margin-left: auto; }
.tk-nav { display: flex; flex-direction: column; gap: 2px; overflow-y: auto; }
.tk-nav-group-label { font-size: 10.5px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; color: #8A9C97; padding: 10px 12px 4px; }
.tk-nav-item { position: relative; display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500; color: #5C716C; background: transparent; border: none; text-align: left; width: 100%; transition: background 0.15s ease, color 0.15s ease; }
.tk-nav-item:hover { background: #EFF4F3; color: #142420; }
.tk-nav-item.active { background: linear-gradient(135deg, #DCE8E5, #CBE0DB); color: #0D302E; box-shadow: inset 0 0 0 1px rgba(18,64,62,0.06); }
.tk-nav-item:focus-visible { outline: 2px solid #12403E; outline-offset: 2px; }
.tk-nav-dot { position: absolute; left: 25px; top: 7px; width: 7px; height: 7px; border-radius: 50%; background: #3E8F76; animation: tk-pulse 1.6s ease-in-out infinite; }

.tk-sidebar-foot { margin-top: auto; padding: 12px; border-radius: 10px; background: #EFF4F3; font-size: 12px; color: #5C716C; display: flex; gap: 8px; align-items: flex-start; line-height: 1.4; }

.tk-main { flex: 1; padding: 32px 40px; overflow-y: auto; }
.tk-page-head { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px; gap: 16px; flex-wrap: wrap; }
.tk-page-title { font-size: 24px; font-weight: 600; }
.tk-page-sub { color: #5C716C; font-size: 14px; margin-top: 4px; }

.tk-intro-card { display: flex; gap: 12px; align-items: flex-start; background: #FFFFFF; border: 1px solid #DCE8E5; border-left: 3px solid #3E8F76; border-radius: 12px; padding: 13px 16px; margin-bottom: 20px; animation: tk-fade-up 0.3s ease both; }
.tk-intro-text { font-size: 13px; color: #3E5E5A; line-height: 1.55; flex: 1; }
.tk-intro-dismiss { background: #DCE8E5; color: #12403E; border: none; padding: 6px 12px; border-radius: 7px; font-size: 12px; font-weight: 600; cursor: pointer; flex-shrink: 0; }
.tk-intro-dismiss:hover { background: #C7DCD7; }

.tk-btn { display: inline-flex; align-items: center; gap: 6px; background: linear-gradient(135deg, #17534F, #0D302E); color: #F5F8F7; border: none; padding: 10px 17px; border-radius: 11px; font-size: 13.5px; font-weight: 500; cursor: pointer; transition: all 0.2s cubic-bezier(.16,1,.3,1); box-shadow: 0 2px 8px -2px rgba(18,64,62,0.35); }
.tk-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 16px -4px rgba(18,64,62,0.45); }
.tk-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.tk-btn:focus-visible { outline: 2px solid #12403E; outline-offset: 2px; }

.tk-toggle { background: #FFFFFF; border: 1px solid #E2E9E7; color: #5C716C; padding: 8px 14px; border-radius: 8px; font-size: 12.5px; font-weight: 600; cursor: pointer; }
.tk-toggle.active { background: #12403E; color: #F5F8F7; border-color: #12403E; }
.tk-toggle.small { padding: 5px 10px; font-size: 11.5px; }

.tk-search { display: flex; align-items: center; gap: 8px; background: #FFFFFF; border: 1px solid #E2E9E7; border-radius: 12px; padding: 9px 12px; font-size: 13.5px; color: #5C716C; min-width: 220px; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
.tk-search:focus-within { border-color: #9FC2BB; box-shadow: 0 0 0 3px rgba(62,143,118,0.12); }

.tk-kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
.tk-card { background: #FFFFFF; border: 1px solid #EAF0EE; border-radius: 18px; padding: 18px 20px; animation: tk-fade-up 0.4s ease both; box-shadow: 0 1px 2px rgba(20,36,32,0.03), 0 10px 24px -14px rgba(20,36,32,0.12); transition: transform 0.25s cubic-bezier(.16,1,.3,1), box-shadow 0.25s ease; }
.tk-card:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(20,36,32,0.04), 0 16px 32px -12px rgba(20,36,32,0.16); }
.tk-kpi-label { font-size: 12.5px; color: #5C716C; font-weight: 500; }
.tk-kpi-value { font-size: 30px; font-weight: 600; margin-top: 6px; }
.tk-kpi-trend { display: flex; align-items: center; gap: 4px; font-size: 12px; color: #3E8F76; margin-top: 6px; font-weight: 500; }
.tk-live-dot { width: 7px; height: 7px; border-radius: 50%; background: #3E8F76; display: inline-block; animation: tk-pulse 1.6s ease-in-out infinite; }

.tk-panel { background: #FFFFFF; border: 1px solid #EAF0EE; border-radius: 18px; padding: 20px 24px; box-shadow: 0 1px 2px rgba(20,36,32,0.03), 0 10px 24px -16px rgba(20,36,32,0.1); }
.tk-panel-title { font-size: 15px; font-weight: 600; margin-bottom: 4px; }
.tk-panel-sub { font-size: 12.5px; color: #5C716C; margin-bottom: 12px; }

.tk-pipeline { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.tk-stage-col { display: flex; flex-direction: column; gap: 10px; }
.tk-stage-head { display: flex; align-items: center; justify-content: space-between; padding: 0 2px; }
.tk-stage-name { font-size: 12.5px; font-weight: 600; }
.tk-pill { font-size: 11px; font-weight: 600; padding: 2px 7px; border-radius: 999px; }
.tk-pcard { background: #FFFFFF; border: 1px solid #EAF0EE; border-radius: 14px; padding: 12px 13px; animation: tk-fade-up 0.35s ease both; cursor: pointer; transition: all 0.2s cubic-bezier(.16,1,.3,1); box-shadow: 0 1px 2px rgba(20,36,32,0.03); }
.tk-pcard:hover { box-shadow: 0 10px 24px -8px rgba(18,64,62,0.16); border-color: #C7D8D4; transform: translateY(-2px); }
.tk-pcard-name { font-size: 13.5px; font-weight: 600; }
.tk-pcard-service { font-size: 12px; color: #5C716C; margin-top: 3px; }
.tk-pcard-foot { display: flex; align-items: center; justify-content: space-between; margin-top: 9px; font-size: 11.5px; color: #8A9C97; }
.tk-pcard-phone { display: flex; align-items: center; gap: 4px; }

.tk-cal-grid { display: grid; grid-template-columns: 64px repeat(5, 1fr); border-top: 1px solid #E2E9E7; border-left: 1px solid #E2E9E7; border-radius: 10px; overflow: hidden; }
.tk-cal-head { background: #EFF4F3; font-size: 12.5px; font-weight: 600; padding: 10px 8px; border-right: 1px solid #E2E9E7; border-bottom: 1px solid #E2E9E7; text-align: center; }
.tk-cal-time { font-size: 11px; color: #8A9C97; padding: 10px 8px; border-right: 1px solid #E2E9E7; border-bottom: 1px solid #E2E9E7; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.tk-cal-cell { min-height: 52px; border-right: 1px solid #E2E9E7; border-bottom: 1px solid #E2E9E7; padding: 4px; }
.tk-cal-appt { background: #DCE8E5; color: #12403E; border-radius: 7px; padding: 5px 7px; font-size: 11px; font-weight: 600; line-height: 1.3; height: 100%; cursor: pointer; transition: background 0.15s ease; }
.tk-cal-appt:hover { background: #C7DCD7; }
.tk-cal-appt-sub { font-weight: 400; color: #3E5E5A; }

.tk-table { width: 100%; border-collapse: collapse; }
.tk-table th { text-align: left; font-size: 11.5px; font-weight: 600; letter-spacing: 0.03em; text-transform: uppercase; color: #8A9C97; padding: 0 10px 10px; border-bottom: 1px solid #E2E9E7; }
.tk-table td { padding: 12px 10px; border-bottom: 1px solid #EFF4F3; font-size: 13.5px; }
.tk-table tr:last-child td { border-bottom: none; }

.tk-task-item { display: flex; align-items: center; gap: 12px; padding: 12px 4px; border-bottom: 1px solid #EFF4F3; }
.tk-task-item:last-child { border-bottom: none; }
.tk-check-box { width: 20px; height: 20px; border-radius: 6px; border: 1.5px solid #C7D8D4; display: flex; align-items: center; justify-content: center; cursor: pointer; flex-shrink: 0; background: #FFFFFF; }
.tk-check-box.done { background: #12403E; border-color: #12403E; color: #F5F8F7; }
.tk-task-text { font-size: 13.5px; flex: 1; }
.tk-task-text.done { color: #8A9C97; text-decoration: line-through; }
.tk-task-tag { font-size: 11px; font-weight: 600; color: #5B7FA6; background: #EAF0F7; padding: 3px 8px; border-radius: 999px; }

.tk-call-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 4px; border-bottom: 1px solid #EFF4F3; }
.tk-call-row:last-child { border-bottom: none; }

.tk-modal-backdrop { position: fixed; inset: 0; background: rgba(13, 26, 24, 0.45); backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); display: flex; align-items: center; justify-content: center; z-index: 40; animation: tk-fade-in 0.2s ease both; padding: 20px; }
.tk-modal { background: #FFFFFF; border-radius: 22px; width: 380px; padding: 24px; animation: tk-pop-in 0.25s cubic-bezier(.16,1,.3,1) both; box-shadow: 0 24px 64px -16px rgba(13,26,24,0.35); }
.tk-modal.wide { width: 540px; max-height: 85vh; overflow-y: auto; }
.tk-modal-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
.tk-modal-title { font-size: 16px; font-weight: 600; }
.tk-close { background: none; border: none; cursor: pointer; color: #8A9C97; padding: 4px; border-radius: 6px; }
.tk-close:hover { background: #EFF4F3; }
.tk-field { margin-bottom: 14px; }
.tk-field label { display: block; font-size: 12.5px; font-weight: 500; color: #5C716C; margin-bottom: 5px; }
.tk-field input, .tk-field select { width: 100%; padding: 9px 11px; border: 1px solid #E2E9E7; border-radius: 10px; font-size: 13.5px; font-family: inherit; color: #142420; background: #FFFFFF; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
.tk-field input:focus, .tk-field select:focus { outline: none; border-color: #3E8F76; box-shadow: 0 0 0 3px rgba(62,143,118,0.15); }

.tk-slot { background: #FFFFFF; border: 1px solid #E2E9E7; color: #142420; padding: 7px 12px; border-radius: 999px; font-size: 12.5px; font-weight: 500; cursor: pointer; }
.tk-slot.active { background: #12403E; color: #F5F8F7; border-color: #12403E; }

.tk-detail-section { margin-bottom: 18px; }
.tk-detail-label { font-size: 11.5px; font-weight: 600; letter-spacing: 0.04em; text-transform: uppercase; color: #8A9C97; margin-bottom: 8px; }
.tk-checklist-item { display: flex; align-items: center; gap: 8px; padding: 5px 0; font-size: 13px; }
.tk-checklist-item.done { color: #142420; }
.tk-checklist-item.pending { color: #8A9C97; }
.tk-checklist-dot { width: 16px; height: 16px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.tk-checklist-dot.done { background: #DCE8E5; color: #12403E; }
.tk-checklist-dot.pending { background: #EFF4F3; color: #C7D8D4; border: 1.5px dashed #C7D8D4; }
.tk-doc-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
.tk-doc-card { border: 1px solid #E2E9E7; border-radius: 10px; padding: 10px; background: #FAFCFB; text-align: center; }
.tk-doc-card svg { color: #8A9C97; margin-bottom: 4px; }
.tk-doc-label { font-size: 11px; font-weight: 600; }
.tk-doc-date { font-size: 10.5px; color: #8A9C97; margin-top: 2px; }
.tk-empty-note { font-size: 12.5px; color: #8A9C97; font-style: italic; }
.tk-notes-box { background: #FAFCFB; border: 1px solid #E2E9E7; border-radius: 10px; padding: 12px; font-size: 13px; color: #3E5E5A; line-height: 1.5; }

.tk-archive-suggestion { padding: 9px 10px; border-radius: 8px; cursor: pointer; font-size: 13.5px; font-weight: 500; }
.tk-archive-suggestion:hover { background: #EFF4F3; }
.tk-timeline { position: relative; padding-left: 4px; }
.tk-timeline-item { display: flex; gap: 14px; position: relative; padding-bottom: 24px; }
.tk-timeline-item:last-child { padding-bottom: 0; }
.tk-timeline-item:last-child .tk-timeline-line { display: none; }
.tk-timeline-dot { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; z-index: 1; }
.tk-timeline-line { position: absolute; left: 13px; top: 28px; bottom: -24px; width: 2px; background: #E2E9E7; }
.tk-timeline-content { padding-top: 4px; }
.tk-timeline-date { font-size: 11px; color: #8A9C97; margin-bottom: 2px; }
.tk-timeline-label { font-size: 13.5px; font-weight: 500; }
.tk-timeline-clickable { cursor: pointer; }
.tk-timeline-clickable:hover .tk-timeline-content { opacity: 0.75; }

.tk-dropzone { border: 2px dashed #C7D8D4; border-radius: 12px; padding: 18px; text-align: center; color: #8A9C97; font-size: 12.5px; cursor: pointer; transition: border-color 0.15s ease, background 0.15s ease; margin-top: 10px; }
.tk-dropzone svg { margin-bottom: 6px; color: #8A9C97; }
.tk-dropzone.active { border-color: #3E8F76; background: #E4F3EE; color: #3E8F76; }
.tk-dropzone.active svg { color: #3E8F76; }
.tk-dropzone-sub { font-size: 11px; margin-top: 2px; color: #B7C4C0; }

.tk-top-post-thumb { width: 100%; aspect-ratio: 16/9; background: linear-gradient(135deg, #12403E, #3E8F76); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #F5F8F7; }

.tk-toast { position: fixed; bottom: 24px; right: 24px; z-index: 50; background: #12403E; color: #F5F8F7; border-radius: 13px; padding: 14px 16px; display: flex; gap: 10px; max-width: 320px; box-shadow: 0 12px 30px rgba(18, 64, 62, 0.25); animation: tk-slide-in 0.3s ease both; }
.tk-toast-title { font-size: 13px; font-weight: 600; margin-bottom: 3px; }
.tk-toast-body { font-size: 12px; color: #B9CEC9; line-height: 1.4; }
.tk-toast-close { background: none; border: none; color: #B9CEC9; cursor: pointer; flex-shrink: 0; }

@keyframes tk-fade-up { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
@keyframes tk-fade-in { from { opacity: 0; } to { opacity: 1; } }
@keyframes tk-pop-in { from { opacity: 0; transform: scale(0.96); } to { opacity: 1; transform: scale(1); } }
@keyframes tk-slide-in { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
@keyframes tk-pulse { 0%, 100% { box-shadow: 0 0 0 0 rgba(62,143,118,0.5); } 50% { box-shadow: 0 0 0 5px rgba(62,143,118,0); } }

@media (prefers-reduced-motion: reduce) { .tk-card, .tk-pcard, .tk-modal-backdrop, .tk-modal, .tk-toast, .tk-live-dot, .tk-nav-dot { animation: none !important; } }

.tk-ai-loading { display: flex; align-items: center; gap: 10px; font-size: 12.5px; color: #3E8F76; margin-top: 10px; }
.tk-ai-spinner { width: 14px; height: 14px; border-radius: 50%; border: 2px solid #DCE8E5; border-top-color: #3E8F76; animation: tk-spin 0.8s linear infinite; flex-shrink: 0; }
.tk-ai-summary { margin-top: 12px; background: #FAFCFB; border: 1px solid #DCE8E5; border-radius: 10px; padding: 12px 14px; animation: tk-fade-up 0.3s ease both; }
.tk-ai-summary-title { display: flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 600; color: #3E8F76; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.04em; }
.tk-ai-summary-row { font-size: 12.5px; line-height: 1.6; margin-bottom: 3px; }
.tk-ai-summary-note { font-size: 11px; color: #8A9C97; font-style: italic; margin-top: 6px; }
@keyframes tk-spin { to { transform: rotate(360deg); } }

.tk-welcome { min-height: 100vh; width: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; background: linear-gradient(160deg, #0D302E, #12403E 45%, #1A5450); color: #F5F8F7; text-align: center; padding: 40px; font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; animation: tk-fade-in 0.4s ease both; position: relative; overflow: hidden; }
.tk-welcome::before { content: ''; position: absolute; width: 600px; height: 600px; border-radius: 50%; background: radial-gradient(circle, rgba(201,138,46,0.18), transparent 70%); top: -220px; right: -160px; pointer-events: none; }
.tk-welcome::after { content: ''; position: absolute; width: 500px; height: 500px; border-radius: 50%; background: radial-gradient(circle, rgba(62,143,118,0.22), transparent 70%); bottom: -200px; left: -140px; pointer-events: none; }
.tk-welcome > * { position: relative; z-index: 1; }
.tk-welcome-badge { display: inline-flex; align-items: center; gap: 5px; font-size: 10.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: #F0DDB2; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.2); padding: 5px 12px; border-radius: 999px; margin-bottom: 28px; animation: tk-fade-up 0.5s ease both; }
.tk-welcome-logo { width: 64px; height: 64px; border-radius: 16px; background: #F5F8F7; color: #12403E; display: flex; align-items: center; justify-content: center; font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; font-weight: 700; font-size: 24px; margin-bottom: 24px; animation: tk-fade-up 0.5s ease both; animation-delay: 0.08s; }
.tk-welcome-title { font-size: 36px; font-weight: 600; margin-bottom: 14px; animation: tk-fade-up 0.5s ease both; animation-delay: 0.15s; }
.tk-welcome-sub { font-size: 15px; color: #C7DCD7; max-width: 480px; line-height: 1.65; margin-bottom: 30px; animation: tk-fade-up 0.5s ease both; animation-delay: 0.2s; }
.tk-welcome-hook { font-size: 19px; color: #F5F8F7; font-weight: 500; max-width: 460px; margin-bottom: 22px; }
.tk-welcome-pills { display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; margin-bottom: 32px; animation: tk-fade-up 0.5s ease both; animation-delay: 0.22s; }
.tk-welcome-pill { font-size: 11.5px; font-weight: 500; color: #E4F3EE; background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.14); padding: 6px 12px; border-radius: 999px; }
.tk-welcome-btn { padding: 13px 26px; font-size: 14.5px; background: #F5F8F7 !important; color: #12403E !important; animation: tk-fade-up 0.5s ease both; animation-delay: 0.28s; }
.tk-welcome-btn:hover { background: #E4F3EE !important; }
.tk-welcome-foot { margin-top: 36px; font-size: 11.5px; color: rgba(245,248,247,0.5); animation: tk-fade-up 0.5s ease both; animation-delay: 0.34s; }

@media (max-width: 860px) {
  .tk-sidebar { width: 72px; }
  .tk-logo-text, .tk-badge, .tk-nav-item span, .tk-sidebar-foot, .tk-nav-group-label, .tk-tour-banner { display: none; }
  .tk-nav-item { justify-content: center; }
  .tk-main { padding: 20px; }
  .tk-kpi-grid, .tk-pipeline, .tk-doc-grid { grid-template-columns: 1fr 1fr; }
}
`;
function CrmDemo() {
	const today = /* @__PURE__ */ new Date();
	const [showWelcome, setShowWelcome] = (0, import_react.useState)(true);
	const [tab, setTab] = (0, import_react.useState)("dashboard");
	const [patients, setPatients] = (0, import_react.useState)(INITIAL_PATIENTS);
	const [invoices, setInvoices] = (0, import_react.useState)(INITIAL_INVOICES);
	const patientDelta = Math.max(0, patients.length - INITIAL_PATIENTS.length);
	const unpaidTotal = invoices.filter((i) => i.status !== "Zaplatená").reduce((sum, i) => sum + i.amount, 0);
	const [tasks, setTasks] = (0, import_react.useState)(INITIAL_TASKS_SAFE());
	const [invoiceView, setInvoiceView] = (0, import_react.useState)("issued");
	const [showPatientForm, setShowPatientForm] = (0, import_react.useState)(false);
	const [showInvoiceForm, setShowInvoiceForm] = (0, import_react.useState)(false);
	const [showTaskForm, setShowTaskForm] = (0, import_react.useState)(false);
	const [openPatient, setOpenPatient] = (0, import_react.useState)(null);
	const [openInvoice, setOpenInvoice] = (0, import_react.useState)(null);
	const [openEvent, setOpenEvent] = (0, import_react.useState)(null);
	const [toast, setToast] = (0, import_react.useState)(null);
	const [patientForm, setPatientForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		service: SERVICES[0],
		notes: ""
	});
	const [aiAnalyzing, setAiAnalyzing] = (0, import_react.useState)(false);
	const [aiSummary, setAiSummary] = (0, import_react.useState)(null);
	const [invoiceForm, setInvoiceForm] = (0, import_react.useState)({
		patient: INITIAL_PATIENTS[0].name,
		companyName: INITIAL_PATIENTS[0].name,
		ico: "",
		dic: "",
		vatPayer: false,
		amount: "",
		showCompanyFields: false
	});
	const [taskForm, setTaskForm] = (0, import_react.useState)({ text: "" });
	const [archiveQuery, setArchiveQuery] = (0, import_react.useState)("");
	const [archivePatient, setArchivePatient] = (0, import_react.useState)(null);
	const [visited, setVisited] = (0, import_react.useState)({});
	const [dismissedIntro, setDismissedIntro] = (0, import_react.useState)({});
	const [bannerDismissed, setBannerDismissed] = (0, import_react.useState)(false);
	const [confirmed, setConfirmed] = (0, import_react.useState)({});
	const [booking, setBooking] = (0, import_react.useState)({
		service: SERVICES[0],
		doctor: DOCTORS[0],
		slot: "",
		name: "",
		phone: ""
	});
	const [bookingDone, setBookingDone] = (0, import_react.useState)(false);
	function INITIAL_TASKS_SAFE() {
		return [
			{
				id: 1,
				text: "Objednať materiál na implantáty na budúci týždeň",
				done: false,
				patient: null
			},
			{
				id: 2,
				text: "Pripraviť podklady pre poisťovňu",
				done: false,
				patient: "Peter Malík"
			},
			{
				id: 3,
				text: "Potvrdiť dodanie zubnej protézy z laboratória",
				done: true,
				patient: null
			},
			{
				id: 4,
				text: "Zavolať pacientom s omeškanou platbou",
				done: false,
				patient: "Peter Malík"
			},
			{
				id: 5,
				text: "Skontrolovať zásoby anestetík",
				done: true,
				patient: null
			}
		];
	}
	function showDisclaimer(title) {
		setToast({
			title,
			body: "Toto je ukážkový template určený na demonštráciu. Vo vašom vlastnom systéme by boli tieto dáta súkromné a viditeľné len pre vašu kliniku."
		});
	}
	function selectTab(id) {
		setTab(id);
		setVisited((v) => ({
			...v,
			[id]: true
		}));
	}
	function addPatient(e) {
		e.preventDefault();
		if (!patientForm.name.trim()) return;
		const entry = {
			id: Date.now(),
			name: patientForm.name.trim(),
			phone: patientForm.phone.trim() || "—",
			service: patientForm.service,
			stage: "Nový dopyt",
			note: formatSk(today),
			checklist: [
				{
					label: "Odporúčanie od lekára",
					done: !!aiSummary
				},
				{
					label: "Vstupný RTG snímok",
					done: false
				},
				{
					label: "Preukaz poistenca",
					done: false
				},
				{
					label: "Podpísaný súhlas s ošetrením",
					done: false
				}
			],
			xrays: [],
			notes: patientForm.notes.trim() || "Zatiaľ bez poznámok."
		};
		setPatients((p) => [entry, ...p]);
		closePatientForm();
		showDisclaimer("Pacient pridaný");
	}
	function closePatientForm() {
		setShowPatientForm(false);
		setAiAnalyzing(false);
		setAiSummary(null);
		setPatientForm({
			name: "",
			phone: "",
			service: SERVICES[0],
			notes: ""
		});
	}
	function runAiAgent() {
		setAiAnalyzing(true);
		setAiSummary(null);
		setTimeout(() => {
			const summary = {
				diagnoses: "Hypertenzia (liečená), bez známych alergií na lokálne anestetiká",
				procedures: "Extrakcia zuba múdrosti (2021), 2× výplň (2023)",
				allergies: "Alergia na penicilín",
				note: "Predchádzajúci lekár odporúča pred zákrokom skontrolovať krvný tlak."
			};
			setAiAnalyzing(false);
			setAiSummary(summary);
			setPatientForm((f) => ({
				...f,
				notes: `${summary.diagnoses}. Doterajšie zákroky: ${summary.procedures}. Alergie: ${summary.allergies}. ${summary.note}`
			}));
		}, 1400);
	}
	function addInvoice(e) {
		e.preventDefault();
		if (!invoiceForm.amount || !invoiceForm.companyName.trim()) return;
		const linkedPatient = patients.find((p) => p.name === invoiceForm.patient);
		const entry = {
			id: Date.now(),
			number: `F2026-0${140 + invoices.length + 1}`,
			patient: invoiceForm.patient,
			companyName: invoiceForm.companyName.trim(),
			ico: invoiceForm.ico.trim(),
			dic: invoiceForm.dic.trim(),
			vatPayer: invoiceForm.vatPayer,
			service: linkedPatient?.service || "Stomatologické ošetrenie",
			amount: Number(invoiceForm.amount),
			date: formatSk(today),
			status: "Čaká na úhradu"
		};
		setInvoices((i) => [entry, ...i]);
		setInvoiceForm({
			patient: patients[0]?.name || "",
			companyName: patients[0]?.name || "",
			ico: "",
			dic: "",
			vatPayer: false,
			amount: "",
			showCompanyFields: false
		});
		setShowInvoiceForm(false);
		showDisclaimer("Platba zaznamenaná");
	}
	function addTask(e) {
		e.preventDefault();
		if (!taskForm.text.trim()) return;
		setTasks((t) => [{
			id: Date.now(),
			text: taskForm.text.trim(),
			done: false,
			patient: null
		}, ...t]);
		setTaskForm({ text: "" });
		setShowTaskForm(false);
		showDisclaimer("Úloha pridaná");
	}
	function toggleTask(id) {
		setTasks((t) => t.map((x) => x.id === id ? {
			...x,
			done: !x.done
		} : x));
	}
	function openPatientByName(name) {
		const found = patients.find((p) => p.name === name);
		if (found) setOpenPatient(found);
	}
	function confirmBooking() {
		setBookingDone(true);
		showDisclaimer("Termín zarezervovaný");
	}
	const nav = [
		{
			group: "Prehľad",
			items: [{
				id: "dashboard",
				label: "Prehľad",
				icon: LayoutDashboard
			}]
		},
		{
			group: "Starostlivosť",
			items: [
				{
					id: "patients",
					label: "Pacienti",
					icon: Users
				},
				{
					id: "calendar",
					label: "Kalendár",
					icon: Calendar
				},
				{
					id: "tasks",
					label: "Na vybavenie",
					icon: ListChecks
				},
				{
					id: "archive",
					label: "Archív pacientov",
					icon: History
				},
				{
					id: "booking",
					label: "Rezervácie",
					icon: CalendarPlus
				}
			]
		},
		{
			group: "Marketing",
			items: [{
				id: "content",
				label: "Obsah",
				icon: Megaphone
			}, {
				id: "plan",
				label: "Plán na mesiac",
				icon: Target
			}]
		},
		{
			group: "Financie",
			items: [{
				id: "finance",
				label: "Financie",
				icon: Wallet
			}, {
				id: "invoices",
				label: "Platby",
				icon: Receipt
			}]
		}
	];
	const totalNavItems = nav.reduce((acc, g) => acc + g.items.length, 0);
	function IntroCard({ id }) {
		if (dismissedIntro[id]) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "tk-intro-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-intro-text",
				children: TAB_INTRO[id]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "tk-intro-dismiss",
				onClick: () => setDismissedIntro((d) => ({
					...d,
					[id]: true
				})),
				children: "Rozumiem"
			})]
		});
	}
	function Dropzone({ label, onDropFile }) {
		const [active, setActive] = (0, import_react.useState)(false);
		function handle() {
			if (onDropFile) onDropFile();
			else showDisclaimer("Súbor pripravený na nahratie");
		}
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `tk-dropzone ${active ? "active" : ""}`,
			onDragOver: (e) => {
				e.preventDefault();
				setActive(true);
			},
			onDragLeave: () => setActive(false),
			onDrop: (e) => {
				e.preventDefault();
				setActive(false);
				handle();
			},
			onClick: handle,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { size: 18 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: label }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "tk-dropzone-sub",
					children: "Pretiahnite súbor sem alebo kliknite pre výber"
				})
			]
		});
	}
	function findInvoiceByLabel(label) {
		const m = label.match(/F2026-\d+/);
		if (!m) return null;
		return invoices.find((i) => i.number === m[0]);
	}
	if (showWelcome) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "tk-welcome",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: STYLE }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tk-welcome-badge",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 11 }), " Ukážkový template"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-welcome-logo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 26 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-welcome-title tk-display",
				children: "Vitajte"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tk-welcome-sub tk-welcome-hook",
				children: [
					"Chcete mať všetko na jednom mieste — a ešte aj moderne spracované?",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"Tak ste na správnom mieste."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-welcome-sub",
				style: {
					fontSize: 13.5,
					marginTop: -14
				},
				children: "Takto by mohol vyzerať kompletný systém pre vašu kliniku — pacienti, kalendár, financie, obsah aj rezervácie na jednom mieste, prehľadne prepojené."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tk-welcome-pills",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tk-welcome-pill",
						children: "Pacienti a archív"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tk-welcome-pill",
						children: "Kalendár a rezervácie"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tk-welcome-pill",
						children: "Financie a platby"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tk-welcome-pill",
						children: "Obsah a plán"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "tk-btn tk-welcome-btn",
				onClick: () => setShowWelcome(false),
				children: "Vstúpiť do systému →"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-welcome-foot",
				children: "Pripravené pre kliniky — Miraculum"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "tk-root",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: STYLE }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "tk-sidebar",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "tk-logo-row",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-logo-mark",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 17 })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tk-badge",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 11 }), " Ukážkový template"]
					})] }),
					Object.keys(visited).length < totalNavItems && !bannerDismissed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tk-tour-banner",
						children: ["👉 Klikni na zelené bodky v menu — každá časť ti krátko povie, čo robí.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setBannerDismissed(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 13 })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "tk-nav",
						children: nav.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-nav-group-label",
							children: group.group
						}), group.items.map((item) => {
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `tk-nav-item ${tab === item.id ? "active" : ""}`,
								onClick: () => selectTab(item.id),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 }),
									!visited[item.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tk-nav-dot" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })
								]
							}, item.id);
						})] }, group.group))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tk-sidebar-foot",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							size: 14,
							style: {
								flexShrink: 0,
								marginTop: 1
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ukážka pripravená pre kliniky — Miraculum. Žiadne reálne dáta klientov. Toto je zároveň základ toho, ako by vyzeral reálny systém pre vašu kliniku." })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "tk-main",
				children: [
					tab === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Prehľad kliniky"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-page-sub",
								children: ["Tento týždeň — ", getWeekRange(today)]
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "dashboard" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-kpi-grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Nové dopyty tento týždeň"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: 14 + patientDelta })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +17 % oproti minulému týždňu"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.05s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Naplánované konzultácie"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: 6 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +2 oproti minulému týždňu"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.1s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Konverzný pomer (dopyt → pacient)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
												value: 32,
												suffix: " %"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +4 p. b."]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.15s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-label",
											style: {
												display: "flex",
												alignItems: "center",
												gap: 6
											},
											children: ["Aktívni pacienti ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tk-live-dot" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: 128 + patientDelta })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +9 tento mesiac"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-title",
									children: "Dopyty podľa týždňa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-sub",
									children: "Posledných 8 týždňov"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: 180,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: WEEKLY,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "week",
												tick: {
													fontSize: 12,
													fill: "#8A9C97"
												},
												axisLine: false,
												tickLine: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
												cursor: { fill: "#EFF4F3" },
												contentStyle: {
													borderRadius: 10,
													border: "1px solid #E2E9E7",
													fontSize: 12.5,
													fontFamily: "Inter, sans-serif"
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "dopyty",
												fill: "#12403E",
												radius: [
													6,
													6,
													0,
													0
												]
											})
										]
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-panel",
							style: { marginTop: 16 },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-title",
									children: "Volania na potvrdenie termínu"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-sub",
									children: "Pacienti s naplánovanou konzultáciou tento týždeň"
								}),
								patients.filter((p) => p.stage === "Konzultácia naplánovaná").map((p) => {
									const missing = p.checklist.filter((c) => !c.done).map((c) => c.label);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-call-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											style: {
												fontWeight: 600,
												fontSize: 13.5
											},
											children: [
												p.name,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													style: {
														fontWeight: 400,
														color: "#8A9C97"
													},
													children: ["· ", p.note]
												})
											]
										}), missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											style: {
												fontSize: 12,
												color: "#B8791F",
												marginTop: 2
											},
											children: ["Pripomenúť doniesť: ", missing.join(", ")]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: `tk-toggle small ${confirmed[p.id] ? "active" : ""}`,
											onClick: () => setConfirmed((c) => ({
												...c,
												[p.id]: !c[p.id]
											})),
											children: confirmed[p.id] ? "Potvrdené ✓" : "Zavolať a potvrdiť"
										})]
									}, p.id);
								})
							]
						})
					] }),
					tab === "patients" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-page-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Pacienti"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-sub",
								children: "Cesta pacienta od prvého dopytu po starostlivosť — klikni na kartu pre detail"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									gap: 10
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-search",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 15 }), " Hľadať pacienta…"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "tk-btn",
									onClick: () => setShowPatientForm(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " Pridať pacienta"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "patients" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-pipeline",
							children: STAGES.map((stage) => {
								const items = patients.filter((p) => p.stage === stage);
								const s = STAGE_STYLE[stage];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-stage-col",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-stage-head",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-stage-name",
											children: stage
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-pill",
											style: {
												color: s.color,
												background: s.bg
											},
											children: items.length
										})]
									}), items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-pcard",
										onClick: () => setOpenPatient(p),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "tk-pcard-name",
												children: p.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "tk-pcard-service",
												children: p.service
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "tk-pcard-foot",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "tk-pcard-phone",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 11 }),
														" ",
														p.phone
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.note })]
											})
										]
									}, p.id))]
								}, stage);
							})
						})
					] }),
					tab === "calendar" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Kalendár"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-page-sub",
								children: [
									"Tento týždeň — ",
									getWeekRange(today),
									" — klikni na termín pre detail pacienta"
								]
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "calendar" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-cal-grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-cal-head",
									style: { background: "#FFFFFF" }
								}),
								DAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-cal-head",
									children: d
								}, d)),
								HOURS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-cal-time",
									children: h
								}), DAYS.map((d) => {
									const appt = APPOINTMENTS.find((a) => a.day === d && a.time === h);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-cal-cell",
										children: appt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-cal-appt",
											onClick: () => openPatientByName(appt.name),
											children: [appt.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "tk-cal-appt-sub",
												children: appt.service
											})]
										})
									}, d + h);
								})] }, h))
							]
						})
					] }),
					tab === "tasks" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-page-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Na vybavenie"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-sub",
								children: "Prevádzkové úlohy kliniky"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "tk-btn",
								onClick: () => setShowTaskForm(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " Pridať úlohu"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "tasks" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-panel",
							children: tasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-task-item",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `tk-check-box ${t.done ? "done" : ""}`,
										onClick: () => toggleTask(t.id),
										children: t.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 13 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `tk-task-text ${t.done ? "done" : ""}`,
										children: t.text
									}),
									t.patient && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-task-tag",
										style: { cursor: "pointer" },
										onClick: () => openPatientByName(t.patient),
										children: t.patient
									})
								]
							}, t.id))
						})
					] }),
					tab === "archive" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Archív pacientov"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-sub",
								children: "Zadajte meno a zobrazí sa celá história — dopyty, kontakty, snímky, zákroky aj faktúry na jednom mieste"
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "archive" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-panel",
							style: { marginBottom: 20 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-search",
								style: {
									width: "100%",
									maxWidth: 420
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: archiveQuery,
									onChange: (e) => {
										setArchiveQuery(e.target.value);
										setArchivePatient(null);
									},
									placeholder: "Hľadať podľa mena pacienta…",
									style: {
										border: "none",
										outline: "none",
										width: "100%",
										fontSize: 13.5,
										fontFamily: "inherit",
										background: "transparent",
										color: "#142420"
									}
								})]
							}), archiveQuery && !archivePatient && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: { marginTop: 10 },
								children: patients.filter((p) => p.name.toLowerCase().includes(archiveQuery.toLowerCase())).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-archive-suggestion",
									onClick: () => {
										setArchivePatient(p);
										setArchiveQuery(p.name);
									},
									children: [
										p.name,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											style: {
												color: "#8A9C97",
												fontWeight: 400
											},
											children: ["· ", p.service]
										})
									]
								}, p.id))
							})]
						}),
						archivePatient ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-page-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								style: { fontSize: 20 },
								children: archivePatient.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-page-sub",
								children: [
									archivePatient.service,
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tk-pill",
										style: {
											color: STAGE_STYLE[archivePatient.stage].color,
											background: STAGE_STYLE[archivePatient.stage].bg
										},
										children: archivePatient.stage
									})
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "tk-btn",
								onClick: () => {
									setInvoiceForm({
										patient: archivePatient.name,
										companyName: archivePatient.name,
										ico: "",
										dic: "",
										vatPayer: false,
										amount: "",
										showCompanyFields: false
									});
									setShowInvoiceForm(true);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " Zaznamenať platbu"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-panel",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-timeline",
								children: (TIMELINES[archivePatient.name] || []).map((ev, i) => {
									const meta = EVENT_META[ev.type];
									const Icon = meta.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-timeline-item tk-timeline-clickable",
										onClick: () => setOpenEvent(ev),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "tk-timeline-dot",
												style: {
													background: meta.bg,
													color: meta.color
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 13 })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tk-timeline-line" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "tk-timeline-content",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "tk-timeline-date tk-mono",
													children: ev.date
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "tk-timeline-label",
													children: ev.label
												})]
											})
										]
									}, i);
								})
							})
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-panel",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-empty-note",
								children: "Zadajte meno pacienta vyššie pre zobrazenie jeho histórie."
							})
						})
					] }),
					tab === "booking" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Rezervačná stránka"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-sub",
								children: "Verejný odkaz pre pacientov aj rýchlu rezerváciu na recepcii"
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "booking" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-panel",
							style: { maxWidth: 460 },
							children: !bookingDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Služba" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: booking.service,
										onChange: (e) => setBooking({
											...booking,
											service: e.target.value
										}),
										children: SERVICES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: s,
											children: s
										}, s))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Lekár" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: booking.doctor,
										onChange: (e) => setBooking({
											...booking,
											doctor: e.target.value,
											slot: ""
										}),
										children: DOCTORS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: d,
											children: d
										}, d))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Voľný termín" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										style: {
											display: "flex",
											flexWrap: "wrap",
											gap: 8
										},
										children: (BOOKING_SLOTS[booking.doctor] || []).map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: `tk-slot ${booking.slot === slot ? "active" : ""}`,
											onClick: () => setBooking({
												...booking,
												slot
											}),
											children: slot
										}, slot))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Meno pacienta" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: booking.name,
										onChange: (e) => setBooking({
											...booking,
											name: e.target.value
										}),
										placeholder: "napr. Mária Nová"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Telefón" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: booking.phone,
										onChange: (e) => setBooking({
											...booking,
											phone: e.target.value
										}),
										placeholder: "+421 9xx xxx xxx"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "tk-btn",
									style: {
										width: "100%",
										justifyContent: "center"
									},
									disabled: !booking.slot || !booking.name.trim(),
									onClick: confirmBooking,
									children: "Rezervovať termín"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									textAlign: "center",
									padding: "20px 0"
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, {
										size: 32,
										style: {
											color: "#3E8F76",
											marginBottom: 10
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										style: {
											fontWeight: 600,
											fontSize: 15
										},
										children: "Termín zarezervovaný"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										style: {
											fontSize: 13,
											color: "#5C716C",
											marginTop: 4
										},
										children: [
											booking.service,
											" · ",
											booking.doctor,
											" · ",
											booking.slot
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "tk-btn",
										style: { marginTop: 16 },
										onClick: () => {
											setBookingDone(false);
											setBooking({
												service: SERVICES[0],
												doctor: DOCTORS[0],
												slot: "",
												name: "",
												phone: ""
											});
										},
										children: "Nová rezervácia"
									})
								]
							})
						})
					] }),
					tab === "content" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Obsah a dosah"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-page-sub",
								children: [
									"Organický výkon — tento týždeň (",
									getWeekRange(today),
									")"
								]
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "content" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-kpi-grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Dosah tento týždeň"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: 24800 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +22 % oproti minulému týždňu"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.05s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Zobrazenia (impressions)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: 61200 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +15 % oproti minulému týždňu"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.1s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Priemerný engagement rate"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
												value: 6.8,
												decimals: 1,
												suffix: " %"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +1,2 p. b."]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.15s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Noví sledovatelia"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-value tk-mono",
											children: ["+", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: 142 })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +38 tento týždeň"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "grid",
								gridTemplateColumns: "1.4fr 1fr",
								gap: 16
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-panel",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-panel-title",
										children: "Dosah podľa týždňa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-panel-sub",
										children: "Posledných 8 týždňov"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: 200,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
											data: CONTENT_WEEKLY,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
													dataKey: "week",
													tick: {
														fontSize: 12,
														fill: "#8A9C97"
													},
													axisLine: false,
													tickLine: false
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
													cursor: { fill: "#EFF4F3" },
													contentStyle: {
														borderRadius: 10,
														border: "1px solid #E2E9E7",
														fontSize: 12.5,
														fontFamily: "Inter, sans-serif"
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													dataKey: "dosah",
													fill: "#3E8F76",
													radius: [
														6,
														6,
														0,
														0
													]
												})
											]
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-panel",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-panel-title",
										children: "Najlepší príspevok tohto týždňa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-panel-sub",
										children: "Video — implantáty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-top-post-thumb",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 22 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										style: {
											fontSize: 13.5,
											fontWeight: 600,
											marginTop: 10
										},
										children: "Ako prebieha zavedenie implantátu"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										style: {
											fontSize: 12,
											color: "#5C716C",
											marginTop: 8,
											display: "flex",
											flexDirection: "column",
											gap: 6
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												style: {
													display: "flex",
													alignItems: "center",
													gap: 6
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 13 }), " 18 400 zhliadnutí"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												style: {
													display: "flex",
													alignItems: "center",
													gap: 6
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { size: 13 }), " 890 lajkov"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												style: {
													display: "flex",
													alignItems: "center",
													gap: 6
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { size: 13 }), " 64 komentárov"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												style: {
													display: "flex",
													alignItems: "center",
													gap: 6
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { size: 13 }), " 210 zdieľaní"]
											})
										]
									})
								]
							})]
						})
					] }),
					tab === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Plán na budúci mesiac"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-sub",
								children: "Výkon podľa služby a odporúčané kroky"
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "plan" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-panel",
							style: { marginBottom: 16 },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "tk-table",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Služba" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Počet tento mesiac" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Trend" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Odporúčanie" })
								] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SERVICE_PLAN.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										style: { fontWeight: 600 },
										children: s.service
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "tk-mono",
										children: s.count
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										style: {
											color: s.trend >= 0 ? "#3E8F76" : "#B84A3E",
											fontWeight: 600
										},
										children: [
											s.trend >= 0 ? "+" : "",
											s.trend,
											" %"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										style: {
											fontSize: 12.5,
											color: "#5C716C",
											maxWidth: 300
										},
										children: s.note
									})
								] }, i)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-title",
									children: "Odporúčania na tento týždeň — Estetická stomatológia"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-sub",
									children: "Najslabšia služba tento mesiac (-20 %)"
								}),
								PLAN_RECOMMENDATIONS.map((rec, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										display: "flex",
										justifyContent: "space-between",
										alignItems: "flex-start",
										gap: 12,
										padding: "9px 0",
										borderBottom: i < PLAN_RECOMMENDATIONS.length - 1 ? "1px solid #EFF4F3" : "none"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										style: {
											fontSize: 13.5,
											lineHeight: 1.6
										},
										children: rec
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "tk-toggle small",
										style: { flexShrink: 0 },
										onClick: () => {
											setTasks((t) => [{
												id: Date.now() + i,
												text: rec,
												done: false,
												patient: null
											}, ...t]);
											showDisclaimer("Úloha pridaná");
										},
										children: "+ Ako úloha"
									})]
								}, i))
							]
						})
					] }),
					tab === "finance" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-page-head",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Financie"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-page-sub",
								children: ["Tento mesiac — ", today.toLocaleDateString("sk-SK", {
									month: "long",
									year: "numeric"
								})]
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "finance" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-kpi-grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Tržby tento mesiac"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
												value: 15700,
												suffix: " €"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +11 % oproti minulému mesiacu"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.05s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Priemerná hodnota pacienta"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
												value: 640,
												suffix: " €"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " +6 % oproti minulému mesiacu"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.1s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Neuhradené platby"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
												value: unpaidTotal,
												suffix: " €"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											style: { color: "#B8791F" },
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }),
												" ",
												invoices.filter((i) => i.status === "Po splatnosti").length,
												" po splatnosti"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-card",
									style: { animationDelay: "0.15s" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-label",
											children: "Očakávané tržby (budúci mesiac)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "tk-kpi-value tk-mono",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
												value: 18200,
												suffix: " €"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "tk-kpi-trend",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { size: 13 }), " podľa naplánovaných konzultácií"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-title",
									children: "Tržby podľa služby"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-panel-sub",
									children: "Aktuálny mesiac"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: 200,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: REVENUE_BY_SERVICE,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "service",
												tick: {
													fontSize: 11.5,
													fill: "#8A9C97"
												},
												axisLine: false,
												tickLine: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
												cursor: { fill: "#EFF4F3" },
												contentStyle: {
													borderRadius: 10,
													border: "1px solid #E2E9E7",
													fontSize: 12.5,
													fontFamily: "Inter, sans-serif"
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "trzby",
												fill: "#C98A2E",
												radius: [
													6,
													6,
													0,
													0
												]
											})
										]
									})
								})
							]
						})
					] }),
					tab === "invoices" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-page-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-title tk-display",
								children: "Platby"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-page-sub",
								children: "Čo platia pacienti aj čo platíte vy — na jednom mieste"
							})] }), invoiceView === "issued" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "tk-btn",
								onClick: () => setShowInvoiceForm(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " Zaznamenať platbu"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroCard, { id: "invoices" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								gap: 8,
								marginBottom: 16
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: `tk-toggle ${invoiceView === "issued" ? "active" : ""}`,
								onClick: () => setInvoiceView("issued"),
								children: "Platby od pacientov"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: `tk-toggle ${invoiceView === "received" ? "active" : ""}`,
								onClick: () => setInvoiceView("received"),
								children: "Naše platby (materiál, labor.)"
							})]
						}),
						invoiceView === "issued" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "tk-table",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Číslo" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pacient" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Suma" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Dátum" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Stav" })
								] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: invoices.map((inv) => {
									const s = INVOICE_STYLE[inv.status];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										style: { cursor: "pointer" },
										onClick: () => setOpenInvoice(inv),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "tk-mono",
												children: inv.number
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: {
													textDecoration: "underline",
													textDecorationStyle: "dotted",
													textDecorationColor: "#C7D8D4"
												},
												onClick: (e) => {
													e.stopPropagation();
													openPatientByName(inv.patient);
												},
												children: inv.companyName || inv.patient
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "tk-mono",
												children: [inv.amount, " €"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: inv.date }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tk-pill",
												style: {
													color: s.color,
													background: s.bg
												},
												children: inv.status
											}) })
										]
									}, inv.id);
								}) })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-empty-note",
								style: { marginTop: 10 },
								children: "Klikni na riadok pre detail platby, na meno pacienta pre jeho kartu."
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-panel",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "tk-table",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Číslo" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Dodávateľ" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Suma" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Dátum" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Stav" })
								] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: RECEIVED_INVOICES.map((inv) => {
									const s = INVOICE_STYLE[inv.status];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "tk-mono",
											children: inv.number
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: inv.supplier }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "tk-mono",
											children: [inv.amount, " €"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: inv.date }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tk-pill",
											style: {
												color: s.color,
												background: s.bg
											},
											children: inv.status
										}) })
									] }, inv.id);
								}) })]
							})
						})
					] })
				]
			}),
			showPatientForm && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-modal-backdrop",
				onClick: closePatientForm,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tk-modal",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tk-modal-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-modal-title",
							children: "Pridať pacienta"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "tk-close",
							onClick: closePatientForm,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: addPatient,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Meno a priezvisko" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: patientForm.name,
									onChange: (e) => setPatientForm({
										...patientForm,
										name: e.target.value
									}),
									placeholder: "napr. Mária Nová",
									autoFocus: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Telefón" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: patientForm.phone,
									onChange: (e) => setPatientForm({
										...patientForm,
										phone: e.target.value
									}),
									placeholder: "+421 9xx xxx xxx"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Služba" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: patientForm.service,
									onChange: (e) => setPatientForm({
										...patientForm,
										service: e.target.value
									}),
									children: SERVICES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: s,
										children: s
									}, s))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								style: {
									display: "block",
									fontSize: 12.5,
									fontWeight: 500,
									color: "#5C716C",
									marginBottom: 5
								},
								children: "Zdravotná dokumentácia od predchádzajúceho lekára (voliteľné)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dropzone, {
								label: "Priložiť dokumentáciu — AI agent ju spracuje",
								onDropFile: runAiAgent
							}),
							aiAnalyzing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-ai-loading",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tk-ai-spinner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "AI agent číta dokumentáciu…" })]
							}),
							aiSummary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-ai-summary",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-ai-summary-title",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 13 }), " AI zhrnutie pacienta"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-ai-summary-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Diagnózy:" }),
											" ",
											aiSummary.diagnoses
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-ai-summary-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Doterajšie zákroky:" }),
											" ",
											aiSummary.procedures
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-ai-summary-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Alergie:" }),
											" ",
											aiSummary.allergies
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-ai-summary-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Poznámka lekára:" }),
											" ",
											aiSummary.note
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tk-ai-summary-note",
										children: "Vygenerované AI agentom z priloženého dokumentu — pred uložením prosím overte správnosť."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { marginTop: 14 } }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-btn",
								type: "submit",
								style: {
									width: "100%",
									justifyContent: "center"
								},
								children: "Pridať do „Nový dopyt\""
							})
						]
					})]
				})
			}),
			showInvoiceForm && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-modal-backdrop",
				onClick: () => setShowInvoiceForm(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tk-modal",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tk-modal-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-modal-title",
							children: "Zaznamenať platbu"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "tk-close",
							onClick: () => setShowInvoiceForm(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: addInvoice,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Pacient" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: invoiceForm.patient,
									onChange: (e) => setInvoiceForm({
										...invoiceForm,
										patient: e.target.value,
										companyName: e.target.value
									}),
									children: patients.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: p.name,
										children: p.name
									}, p.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Suma (€)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: invoiceForm.amount,
									onChange: (e) => setInvoiceForm({
										...invoiceForm,
										amount: e.target.value
									}),
									placeholder: "napr. 450"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: 8,
									fontSize: 12.5,
									color: "#5C716C",
									marginBottom: invoiceForm.showCompanyFields ? 12 : 4,
									cursor: "pointer"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: invoiceForm.showCompanyFields,
									onChange: (e) => setInvoiceForm({
										...invoiceForm,
										showCompanyFields: e.target.checked
									}),
									style: { width: "auto" }
								}), "Fakturovať firme / poisťovni (IČO, DIČ, DPH)"]
							}),
							invoiceForm.showCompanyFields && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Názov firmy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: invoiceForm.companyName,
										onChange: (e) => setInvoiceForm({
											...invoiceForm,
											companyName: e.target.value
										}),
										placeholder: "napr. Firma s.r.o."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										display: "grid",
										gridTemplateColumns: "1fr 1fr",
										gap: 10
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "IČO" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: invoiceForm.ico,
											onChange: (e) => setInvoiceForm({
												...invoiceForm,
												ico: e.target.value
											})
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "DIČ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: invoiceForm.dic,
											onChange: (e) => setInvoiceForm({
												...invoiceForm,
												dic: e.target.value
											})
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tk-field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Platca DPH" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: invoiceForm.vatPayer ? "ano" : "nie",
										onChange: (e) => setInvoiceForm({
											...invoiceForm,
											vatPayer: e.target.value === "ano"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "nie",
											children: "Nie je platca DPH"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "ano",
											children: "Platca DPH"
										})]
									})]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-btn",
								type: "submit",
								style: {
									width: "100%",
									justifyContent: "center"
								},
								children: "Uložiť platbu"
							})
						]
					})]
				})
			}),
			showTaskForm && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-modal-backdrop",
				onClick: () => setShowTaskForm(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tk-modal",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tk-modal-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-modal-title",
							children: "Pridať úlohu"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "tk-close",
							onClick: () => setShowTaskForm(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: addTask,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: "Čo treba vybaviť" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: taskForm.text,
								onChange: (e) => setTaskForm({ text: e.target.value }),
								placeholder: "napr. Objednať materiál",
								autoFocus: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "tk-btn",
							type: "submit",
							style: {
								width: "100%",
								justifyContent: "center"
							},
							children: "Pridať úlohu"
						})]
					})]
				})
			}),
			openPatient && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-modal-backdrop",
				onClick: () => setOpenPatient(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tk-modal wide",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-modal-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-modal-title",
								children: openPatient.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									fontSize: 12.5,
									color: "#5C716C",
									marginTop: 2
								},
								children: [
									openPatient.service,
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tk-pill",
										style: {
											color: STAGE_STYLE[openPatient.stage].color,
											background: STAGE_STYLE[openPatient.stage].bg
										},
										children: openPatient.stage
									})
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-close",
								onClick: () => setOpenPatient(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-detail-section",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-detail-label",
								children: "Kontakt"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									fontSize: 13.5,
									display: "flex",
									alignItems: "center",
									gap: 6
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 13 }),
									" ",
									openPatient.phone
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-detail-section",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-detail-label",
								children: "Čo si mal priniesť"
							}), openPatient.checklist.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `tk-checklist-item ${c.done ? "done" : "pending"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `tk-checklist-dot ${c.done ? "done" : "pending"}`,
									children: c.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 10 })
								}), c.label]
							}, i))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-detail-section",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-detail-label",
									children: "Rentgenové snímky a dokumentácia"
								}),
								openPatient.xrays.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-doc-grid",
									children: openPatient.xrays.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "tk-doc-card",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { size: 20 }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "tk-doc-label",
												children: x.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "tk-doc-date",
												children: x.date
											})
										]
									}, i))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-empty-note",
									children: "Zatiaľ žiadne nahraté snímky."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dropzone, { label: "Pridať RTG snímok alebo dokument" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-detail-section",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-detail-label",
								children: "Platby"
							}), invoices.filter((i) => i.patient === openPatient.name).length > 0 ? invoices.filter((i) => i.patient === openPatient.name).map((i) => {
								const s = INVOICE_STYLE[i.status];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										display: "flex",
										justifyContent: "space-between",
										fontSize: 13,
										padding: "5px 0"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										i.service,
										" · ",
										i.date
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tk-pill",
										style: {
											color: s.color,
											background: s.bg
										},
										children: [
											i.amount,
											" € · ",
											i.status
										]
									})]
								}, i.id);
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-empty-note",
								children: "Zatiaľ žiadne platby."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-detail-section",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-detail-label",
								children: "Súvisiace úlohy"
							}), tasks.filter((t) => t.patient === openPatient.name).length > 0 ? tasks.filter((t) => t.patient === openPatient.name).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: 8,
									fontSize: 13,
									padding: "4px 0"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `tk-check-box ${t.done ? "done" : ""}`,
									style: {
										width: 16,
										height: 16
									},
									onClick: () => toggleTask(t.id),
									children: t.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 10 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: t.done ? "tk-task-text done" : "",
									children: t.text
								})]
							}, t.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-empty-note",
								children: "Žiadne naviazané úlohy."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-detail-section",
							style: { marginBottom: 0 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-detail-label",
								children: "Poznámky"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-notes-box",
								children: openPatient.notes
							})]
						})
					]
				})
			}),
			openInvoice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-modal-backdrop",
				onClick: () => setOpenInvoice(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "tk-modal wide",
					onClick: (e) => e.stopPropagation(),
					children: openInvoice.ico || openInvoice.dic || openInvoice.vatPayer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-modal-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tk-modal-title",
								children: ["Faktúra č. ", openInvoice.number]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-close",
								onClick: () => setOpenInvoice(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "grid",
								gridTemplateColumns: "1fr 1fr",
								gap: 16,
								marginBottom: 18
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-detail-label",
									children: "Dodávateľ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: {
										fontSize: 13.5,
										fontWeight: 600
									},
									children: SUPPLIER.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										fontSize: 12.5,
										color: "#5C716C",
										lineHeight: 1.6
									},
									children: [
										SUPPLIER.address,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"IČO: ",
										SUPPLIER.ico,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"DIČ: ",
										SUPPLIER.dic,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"IČ DPH: ",
										SUPPLIER.icDph
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-detail-label",
									children: "Odberateľ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: {
										fontSize: 13.5,
										fontWeight: 600
									},
									children: openInvoice.companyName || openInvoice.patient
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										fontSize: 12.5,
										color: "#5C716C",
										lineHeight: 1.6
									},
									children: [openInvoice.ico ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										"IČO: ",
										openInvoice.ico,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
									] }) : null, openInvoice.dic ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										"DIČ: ",
										openInvoice.dic,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
									] }) : null]
								})
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								gap: 24,
								fontSize: 12.5,
								color: "#5C716C",
								marginBottom: 16
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Dátum vystavenia",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: {
											color: "#142420",
											fontWeight: 500
										},
										children: openInvoice.date
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Splatnosť",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: {
											color: "#142420",
											fontWeight: 500
										},
										children: "14 dní"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Forma úhrady",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: {
											color: "#142420",
											fontWeight: 500
										},
										children: "Prevodom"
									})
								] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "tk-table",
							style: { marginBottom: 14 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Popis" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Suma" })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: openInvoice.service }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "tk-mono",
								children: [openInvoice.amount.toFixed(2).replace(".", ","), " €"]
							})] }) })]
						}),
						openInvoice.vatPayer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: 13,
								lineHeight: 1.8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Základ dane: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tk-mono",
									children: [openInvoice.amount.toFixed(2).replace(".", ","), " €"]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["DPH 20 %: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tk-mono",
									children: [(openInvoice.amount * .2).toFixed(2).replace(".", ","), " €"]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										fontWeight: 600,
										fontSize: 15,
										marginTop: 4
									},
									children: ["Spolu s DPH: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tk-mono",
										children: [(openInvoice.amount * 1.2).toFixed(2).replace(".", ","), " €"]
									})]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: { fontSize: 13 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									color: "#8A9C97",
									marginBottom: 6
								},
								children: "Dodávateľ nie je platcom DPH."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									fontWeight: 600,
									fontSize: 15
								},
								children: ["Suma na úhradu: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tk-mono",
									children: [openInvoice.amount.toFixed(2).replace(".", ","), " €"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: 12,
								color: "#8A9C97",
								marginTop: 16,
								borderTop: "1px solid #E2E9E7",
								paddingTop: 12
							},
							children: ["IBAN: ", SUPPLIER.iban]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-modal-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-modal-title",
								children: "Potvrdenie o platbe"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-close",
								onClick: () => setOpenInvoice(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: 13.5,
								marginBottom: 10
							},
							children: ["Pacient: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								onClick: () => {
									openPatientByName(openInvoice.patient);
									setOpenInvoice(null);
								},
								style: {
									cursor: "pointer",
									textDecoration: "underline",
									textDecorationStyle: "dotted"
								},
								children: openInvoice.companyName || openInvoice.patient
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: 13.5,
								marginBottom: 10
							},
							children: ["Za: ", openInvoice.service]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: 12.5,
								color: "#8A9C97",
								marginBottom: 16
							},
							children: ["Dátum: ", openInvoice.date]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontWeight: 600,
								fontSize: 24
							},
							className: "tk-mono",
							children: [openInvoice.amount.toFixed(2).replace(".", ","), " €"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tk-pill",
							style: {
								marginTop: 8,
								display: "inline-block",
								color: INVOICE_STYLE[openInvoice.status].color,
								background: INVOICE_STYLE[openInvoice.status].bg
							},
							children: openInvoice.status
						})
					] })
				})
			}),
			openEvent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tk-modal-backdrop",
				onClick: () => setOpenEvent(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tk-modal",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tk-modal-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: 10
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-timeline-dot",
									style: {
										background: EVENT_META[openEvent.type].bg,
										color: EVENT_META[openEvent.type].color,
										position: "static"
									},
									children: import_react.createElement(EVENT_META[openEvent.type].icon, { size: 14 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tk-modal-title",
									style: { fontSize: 15 },
									children: openEvent.label
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-close",
								onClick: () => setOpenEvent(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						}),
						openEvent.date && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: 12.5,
								color: "#8A9C97",
								marginBottom: 14
							},
							children: openEvent.date
						}),
						EVENT_DETAIL_META[openEvent.type].fields.map(([label, val], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: { marginBottom: 10 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-detail-label",
								style: { marginBottom: 2 },
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: { fontSize: 13.5 },
								children: val
							})]
						}, i)),
						EVENT_DETAIL_META[openEvent.type].dropzone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dropzone, { label: EVENT_DETAIL_META[openEvent.type].dropLabel }),
						EVENT_DETAIL_META[openEvent.type].linkToInvoice && (() => {
							const inv = findInvoiceByLabel(openEvent.label);
							return inv ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "tk-btn",
								style: { marginTop: 4 },
								onClick: () => {
									setOpenInvoice(inv);
									setOpenEvent(null);
								},
								children: "Zobraziť platbu"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tk-empty-note",
								children: "Platba sa nenašla v module Platby."
							});
						})()
					]
				})
			}),
			toast && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tk-toast",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						size: 18,
						style: {
							flexShrink: 0,
							marginTop: 1
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { flex: 1 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-toast-title",
							children: toast.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tk-toast-body",
							children: toast.body
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "tk-toast-close",
						onClick: () => setToast(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 15 })
					})
				]
			})
		]
	});
}
function CrmDemoPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-brand-navy",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-6 py-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-sm text-brand-green hover:text-brand-green-light",
				children: "← Späť na Miraculum"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrmDemo, {})]
	});
}
//#endregion
export { CrmDemoPage as component };
