import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Logo } from "./Logo-Ci4VJEux.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/logo-greenscreen-U5ZC3YWj.js
var import_jsx_runtime = require_jsx_runtime();
function LogoGreenscreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen w-full flex items-center justify-center bg-white",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				width: 1080,
				height: 1080,
				borderRadius: 48,
				backgroundColor: "#00FF00"
			},
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
				size: Math.round(864),
				className: "text-white"
			})
		})
	});
}
//#endregion
export { LogoGreenscreen as component };
